// background.js - Service Worker for Mentor Messenger Magic Extension

// Optimization Libraries
import { openDB } from './lib/idb.js';
import WorkerPool from './lib/workerpool.js';
import LRUCache from './lib/lru-cache.js';

// Initialize optimizations
let dbPromise;
try {
  dbPromise = openDB('mentor-messenger', 1, {
    upgrade(db) {
      if (!db.objectStoreNames.contains('messages')) {
        const store = db.createObjectStore('messages', { keyPath: 'id' });
        store.createIndex('status', 'status');
        store.createIndex('scheduledFor', 'scheduledFor');
      }
      if (!db.objectStoreNames.contains('analytics')) {
        db.createObjectStore('analytics', { keyPath: 'id', autoIncrement: true });
      }
    },
  });
} catch (e) {
  console.error('Failed to initialize IndexedDB:', e);
}

const workerPool = new WorkerPool('worker.js');
const templateCache = new LRUCache({ max: 50, ttl: 1000 * 60 * 60 }); // 1 hour TTL

// Constants
const API_BASE_URL = 'https://api.mentormessengermagic.com'; // Replace with actual API URL
const STORAGE_KEYS = {
  AUTH: 'auth',
  TEMPLATES: 'templates',
  SETTINGS: 'settings',
  MESSAGE_QUEUE: 'messageQueue',
  RESOURCE_USAGE: 'resourceUsage',
  PROFILES: 'profiles',
  CONVERSATIONS: 'conversations'
};

// Initialize extension when installed
chrome.runtime.onInstalled.addListener(async () => {
  console.log('Mentor Messenger Magic Extension installed');
  
  // Initialize storage with default values
  await initializeStorage();
  
  // Set up message queue
  await initializeMessageQueue();
  
  // Set up resource monitoring
  initializeResourceMonitoring();
});

// Handle messages from content scripts and popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Background received message:', message);
  
  // Route message to appropriate handler
  switch (message.action) {
    case 'sendMessage':
      handleSendMessage(message.data, sendResponse);
      return true; // Keep channel open for async response
      
    case 'queueMessage':
      handleQueueMessage(message.data, sendResponse);
      return true;
      
    case 'getTemplates':
      handleGetTemplates(sendResponse);
      return true;
      
    case 'saveTemplate':
      handleSaveTemplate(message.data, sendResponse);
      return true;
      
    case 'getResourceUsage':
      handleGetResourceUsage(sendResponse);
      return true;
      
    case 'saveProfile':
      handleSaveProfile(message.data, sendResponse);
      return true;
      
    case 'getProfiles':
      handleGetProfiles(message.data, sendResponse);
      return true;
      
    case 'saveConversation':
      handleSaveConversation(message.data, sendResponse);
      return true;
      
    case 'getSettings':
      handleGetSettings(sendResponse);
      return true;
      
    case 'updateSettings':
      handleUpdateSettings(message.data, sendResponse);
      return true;
      
    default:
      console.log('Unknown action:', message.action);
      sendResponse({ success: false, error: 'Unknown action' });
  }
});

// Initialize storage with default values
async function initializeStorage() {
  const defaults = {
    [STORAGE_KEYS.AUTH]: { isAuthenticated: false, token: null },
    [STORAGE_KEYS.TEMPLATES]: getDefaultTemplates(),
    [STORAGE_KEYS.SETTINGS]: getDefaultSettings(),
    [STORAGE_KEYS.MESSAGE_QUEUE]: [],
    [STORAGE_KEYS.RESOURCE_USAGE]: {
      messagesSent: 0,
      templatesUsed: 0,
      automationActions: 0,
      lastReset: new Date().toISOString()
    },
    [STORAGE_KEYS.PROFILES]: {},
    [STORAGE_KEYS.CONVERSATIONS]: {}
  };
  
  // Set defaults only if not already set
  for (const [key, value] of Object.entries(defaults)) {
    const data = await chrome.storage.local.get(key);
    if (!data[key]) {
      await chrome.storage.local.set({ [key]: value });
    }
  }
}

// Initialize message queue
async function initializeMessageQueue() {
  // Get existing queue
  const data = await chrome.storage.local.get(STORAGE_KEYS.MESSAGE_QUEUE);
  const queue = data[STORAGE_KEYS.MESSAGE_QUEUE] || [];
  
  // Process any pending messages
  if (queue.length > 0) {
    console.log(`Found ${queue.length} pending messages in queue`);
    // We don't automatically process the queue on startup to avoid unexpected actions
    // User will need to trigger processing from the popup
  }
}

// Initialize resource monitoring
function initializeResourceMonitoring() {
  // Set up periodic resource usage sync
  // Note: This doesn't use scheduled tasks, just tracks usage during active sessions
  console.log('Resource monitoring initialized');
}

// Handle sending a message immediately
async function handleSendMessage(data, sendResponse) {
  try {
    console.log('Sending message:', data);
    
    // Validate data
    if (!data.recipientId || !data.content) {
      throw new Error('Missing required fields');
    }
    
    // Check rate limits
    if (!checkRateLimits()) {
      throw new Error('Rate limit exceeded. Please try again later.');
    }
    
    // Send message to content script to execute
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs.length === 0) {
      throw new Error('No active tab found');
    }
    
    // Tell content script to send the message
    chrome.tabs.sendMessage(tabs[0].id, {
      action: 'executeMessageSend',
      data: data
    }, async (response) => {
      if (response && response.success) {
        // Update resource usage
        await updateResourceUsage('messagesSent');
        if (data.templateId) {
          await updateResourceUsage('templatesUsed');
        }
        
        // Save to conversation history
        await saveMessageToHistory(data);
        
        sendResponse({ success: true, message: 'Message sent successfully' });
      } else {
        sendResponse({ 
          success: false, 
          error: response ? response.error : 'Failed to send message' 
        });
      }
    });
  } catch (error) {
    console.error('Error sending message:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// Handle queuing a message for later sending
async function handleQueueMessage(data, sendResponse) {
  try {
    console.log('Queuing message:', data);
    
    // Validate data
    if (!data.recipientId || !data.content) {
      throw new Error('Missing required fields');
    }
    
    // Get current queue
    const storage = await chrome.storage.local.get(STORAGE_KEYS.MESSAGE_QUEUE);
    const queue = storage[STORAGE_KEYS.MESSAGE_QUEUE] || [];
    
    // Add message to queue with timestamp
    const queueItem = {
      ...data,
      queuedAt: new Date().toISOString(),
      status: 'queued'
    };
    
    queue.push(queueItem);
    
    // Save updated queue
    await chrome.storage.local.set({ [STORAGE_KEYS.MESSAGE_QUEUE]: queue });
    
    // Update resource usage
    await updateResourceUsage('automationActions');
    
    sendResponse({ 
      success: true, 
      message: 'Message queued successfully',
      queuePosition: queue.length
    });
  } catch (error) {
    console.error('Error queuing message:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// Handle getting templates
async function handleGetTemplates(sendResponse) {
  try {
    const data = await chrome.storage.local.get(STORAGE_KEYS.TEMPLATES);
    const templates = data[STORAGE_KEYS.TEMPLATES] || [];
    sendResponse({ success: true, templates });
  } catch (error) {
    console.error('Error getting templates:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// Handle saving a template
async function handleSaveTemplate(template, sendResponse) {
  try {
    // Validate template
    if (!template.name || !template.content) {
      throw new Error('Template must have a name and content');
    }
    
    // Get existing templates
    const data = await chrome.storage.local.get(STORAGE_KEYS.TEMPLATES);
    let templates = data[STORAGE_KEYS.TEMPLATES] || [];
    
    // Check if updating existing template
    const index = templates.findIndex(t => t.id === template.id);
    
    if (index >= 0) {
      // Update existing template
      templates[index] = { ...templates[index], ...template };
    } else {
      // Add new template with ID
      templates.push({
        ...template,
        id: generateId(),
        createdAt: new Date().toISOString()
      });
    }
    
    // Save updated templates
    await chrome.storage.local.set({ [STORAGE_KEYS.TEMPLATES]: templates });
    
    sendResponse({ success: true, templates });
  } catch (error) {
    console.error('Error saving template:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// Handle getting resource usage
async function handleGetResourceUsage(sendResponse) {
  try {
    const data = await chrome.storage.local.get(STORAGE_KEYS.RESOURCE_USAGE);
    const resourceUsage = data[STORAGE_KEYS.RESOURCE_USAGE] || {
      messagesSent: 0,
      templatesUsed: 0,
      automationActions: 0,
      lastReset: new Date().toISOString()
    };
    
    sendResponse({ success: true, resourceUsage });
  } catch (error) {
    console.error('Error getting resource usage:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// Handle saving a profile
async function handleSaveProfile(profile, sendResponse) {
  try {
    // Validate profile
    if (!profile.id) {
      throw new Error('Profile must have an ID');
    }
    
    // Get existing profiles
    const data = await chrome.storage.local.get(STORAGE_KEYS.PROFILES);
    const profiles = data[STORAGE_KEYS.PROFILES] || {};
    
    // Add or update profile
    profiles[profile.id] = {
      ...profile,
      updatedAt: new Date().toISOString()
    };
    
    // Save updated profiles
    await chrome.storage.local.set({ [STORAGE_KEYS.PROFILES]: profiles });
    
    sendResponse({ success: true, profile: profiles[profile.id] });
  } catch (error) {
    console.error('Error saving profile:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// Handle getting profiles
async function handleGetProfiles(query, sendResponse) {
  try {
    const data = await chrome.storage.local.get(STORAGE_KEYS.PROFILES);
    const profiles = data[STORAGE_KEYS.PROFILES] || {};
    
    // If query is provided, filter profiles
    let result = profiles;
    if (query) {
      result = Object.values(profiles).filter(profile => {
        // Simple search across all fields
        const searchText = JSON.stringify(profile).toLowerCase();
        return searchText.includes(query.toLowerCase());
      });
    }
    
    sendResponse({ success: true, profiles: result });
  } catch (error) {
    console.error('Error getting profiles:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// Handle saving a conversation
async function handleSaveConversation(conversation, sendResponse) {
  try {
    // Validate conversation
    if (!conversation.participantId) {
      throw new Error('Conversation must have a participant ID');
    }
    
    // Get existing conversations
    const data = await chrome.storage.local.get(STORAGE_KEYS.CONVERSATIONS);
    const conversations = data[STORAGE_KEYS.CONVERSATIONS] || {};
    
    // Get or create conversation for this participant
    const existingConversation = conversations[conversation.participantId] || {
      participantId: conversation.participantId,
      messages: [],
      createdAt: new Date().toISOString()
    };
    
    // Add new messages
    if (conversation.messages && conversation.messages.length > 0) {
      existingConversation.messages = [
        ...existingConversation.messages,
        ...conversation.messages.map(msg => ({
          ...msg,
          timestamp: msg.timestamp || new Date().toISOString()
        }))
      ];
    }
    
    // Update conversation
    existingConversation.updatedAt = new Date().toISOString();
    conversations[conversation.participantId] = existingConversation;
    
    // Save updated conversations
    await chrome.storage.local.set({ [STORAGE_KEYS.CONVERSATIONS]: conversations });
    
    sendResponse({ success: true, conversation: existingConversation });
  } catch (error) {
    console.error('Error saving conversation:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// Handle getting settings
async function handleGetSettings(sendResponse) {
  try {
    const data = await chrome.storage.local.get(STORAGE_KEYS.SETTINGS);
    const settings = data[STORAGE_KEYS.SETTINGS] || getDefaultSettings();
    
    sendResponse({ success: true, settings });
  } catch (error) {
    console.error('Error getting settings:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// Handle updating settings
async function handleUpdateSettings(settings, sendResponse) {
  try {
    // Get existing settings
    const data = await chrome.storage.local.get(STORAGE_KEYS.SETTINGS);
    const existingSettings = data[STORAGE_KEYS.SETTINGS] || getDefaultSettings();
    
    // Merge settings
    const updatedSettings = { ...existingSettings, ...settings };
    
    // Save updated settings
    await chrome.storage.local.set({ [STORAGE_KEYS.SETTINGS]: updatedSettings });
    
    sendResponse({ success: true, settings: updatedSettings });
  } catch (error) {
    console.error('Error updating settings:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// Save message to conversation history
async function saveMessageToHistory(messageData) {
  try {
    // Get existing conversations
    const data = await chrome.storage.local.get(STORAGE_KEYS.CONVERSATIONS);
    const conversations = data[STORAGE_KEYS.CONVERSATIONS] || {};
    
    // Get or create conversation for this recipient
    const existingConversation = conversations[messageData.recipientId] || {
      participantId: messageData.recipientId,
      messages: [],
      createdAt: new Date().toISOString()
    };
    
    // Add new message
    existingConversation.messages.push({
      content: messageData.content,
      sender: 'user',
      timestamp: new Date().toISOString(),
      templateId: messageData.templateId
    });
    
    // Update conversation
    existingConversation.updatedAt = new Date().toISOString();
    conversations[messageData.recipientId] = existingConversation;
    
    // Save updated conversations
    await chrome.storage.local.set({ [STORAGE_KEYS.CONVERSATIONS]: conversations });
    
    return true;
  } catch (error) {
    console.error('Error saving message to history:', error);
    return false;
  }
}

// Update resource usage counters
async function updateResourceUsage(metric) {
  try {
    // Get current resource usage
    const data = await chrome.storage.local.get(STORAGE_KEYS.RESOURCE_USAGE);
    const resourceUsage = data[STORAGE_KEYS.RESOURCE_USAGE] || {
      messagesSent: 0,
      templatesUsed: 0,
      automationActions: 0,
      lastReset: new Date().toISOString()
    };
    
    // Increment the specified metric
    if (resourceUsage[metric] !== undefined) {
      resourceUsage[metric]++;
    }
    
    // Update timestamp
    resourceUsage.lastUpdated = new Date().toISOString();
    
    // Save updated resource usage
    await chrome.storage.local.set({ [STORAGE_KEYS.RESOURCE_USAGE]: resourceUsage });
    
    // Sync with backend if authenticated
    syncResourceUsage(resourceUsage);
    
    return true;
  } catch (error) {
    console.error('Error updating resource usage:', error);
    return false;
  }
}

// Sync resource usage with backend
async function syncResourceUsage(resourceUsage) {
  try {
    // Get authentication status
    const data = await chrome.storage.local.get(STORAGE_KEYS.AUTH);
    const auth = data[STORAGE_KEYS.AUTH];
    
    // Only sync if authenticated
    if (auth && auth.isAuthenticated && auth.token) {
      // This would be an API call to the backend
      console.log('Syncing resource usage with backend:', resourceUsage);
      
      // In a real implementation, this would be an actual API call
      // For now, we just log it
    }
  } catch (error) {
    console.error('Error syncing resource usage:', error);
  }
}

// Check rate limits to prevent abuse
function checkRateLimits() {
  // In a real implementation, this would check against stored rate limits
  // For now, we always return true
  return true;
}

// Get default templates
function getDefaultTemplates() {
  return [
    {
      id: 'template-1',
      name: 'Initial Outreach',
      category: 'Mentor Outreach',
      content: `Hello {{name}},

I noticed your profile on MicroMentor and was impressed by your experience in {{expertise}}. I'm currently working on {{project}} and would appreciate your guidance on {{specific_topic}}.

Would you be open to a conversation about this? I'm particularly interested in learning more about {{interest_area}}.

Thank you for your time and consideration.

Best regards,
{{user_name}}`
    },
    {
      id: 'template-2',
      name: 'Follow-up Message',
      category: 'Follow-up',
      content: `Hello {{name}},

I wanted to follow up on my previous message regarding {{topic}}. I'm still very interested in your insights on this matter.

If you have a few minutes to connect, I would greatly appreciate it. I'm flexible with timing and can work around your schedule.

Thank you again for considering my request.

Best regards,
{{user_name}}`
    },
    {
      id: 'template-3',
      name: 'Thank You',
      category: 'Relationship Building',
      content: `Hello {{name}},

I wanted to express my sincere gratitude for our recent conversation about {{topic}}. Your insights on {{specific_point}} were particularly valuable and have already helped me {{benefit}}.

I've taken action on your suggestions regarding {{suggestion}} and will keep you updated on the progress.

Thank you again for your time and expertise.

Best regards,
{{user_name}}`
    }
  ];
}

// Get default settings
function getDefaultSettings() {
  return {
    rateLimit: {
      messagesPerHour: 10,
      messagesPerDay: 50
    },
    notifications: {
      enabled: true,
      newMessages: true,
      queueUpdates: true,
      resourceAlerts: true
    },
    automation: {
      confirmBeforeSend: true,
      enableQueueProcessing: true
    },
    ui: {
      showTemplateButton: true,
      enableInlinePreview: true
    }
  };
}

// Generate a unique ID
function generateId() {
  return 'id-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
}
