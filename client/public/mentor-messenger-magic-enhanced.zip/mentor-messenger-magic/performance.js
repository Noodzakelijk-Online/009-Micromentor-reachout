/**
 * Performance Optimization Module
 * Provides utilities for optimizing extension performance
 */

class PerformanceOptimizer {
  constructor() {
    this.metrics = {
      loadTimes: [],
      apiCalls: [],
      storageOperations: [],
      renderTimes: []
    };
    this.caches = new Map();
  }

  /**
   * Lazy load a component
   */
  lazyLoad(loader) {
    let component = null;
    return async (...args) => {
      if (!component) {
        component = await loader();
      }
      return component(...args);
    };
  }

  /**
   * Debounce function calls
   */
  debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  /**
   * Throttle function calls
   */
  throttle(func, limit) {
    let inThrottle;
    return function(...args) {
      if (!inThrottle) {
        func.apply(this, args);
        inThrottle = true;
        setTimeout(() => inThrottle = false, limit);
      }
    };
  }

  /**
   * Memoize function results
   */
  memoize(func, keyGenerator = (...args) => JSON.stringify(args)) {
    const cache = new Map();
    return function(...args) {
      const key = keyGenerator(...args);
      if (cache.has(key)) {
        return cache.get(key);
      }
      const result = func.apply(this, args);
      cache.set(key, result);
      return result;
    };
  }

  /**
   * Batch API requests
   */
  createBatcher(batchSize = 10, batchDelay = 100) {
    let queue = [];
    let timeout = null;

    const processBatch = async () => {
      if (queue.length === 0) return;

      const batch = queue.splice(0, batchSize);
      const promises = batch.map(item => item.request());
      
      try {
        const results = await Promise.all(promises);
        batch.forEach((item, index) => {
          item.resolve(results[index]);
        });
      } catch (error) {
        batch.forEach(item => {
          item.reject(error);
        });
      }

      if (queue.length > 0) {
        timeout = setTimeout(processBatch, batchDelay);
      }
    };

    return (request) => {
      return new Promise((resolve, reject) => {
        queue.push({ request, resolve, reject });

        if (timeout) {
          clearTimeout(timeout);
        }

        if (queue.length >= batchSize) {
          processBatch();
        } else {
          timeout = setTimeout(processBatch, batchDelay);
        }
      });
    };
  }

  /**
   * Implement virtual scrolling for large lists
   */
  createVirtualScroller(container, items, itemHeight, renderItem) {
    const totalHeight = items.length * itemHeight;
    const visibleCount = Math.ceil(container.clientHeight / itemHeight);
    const buffer = 5; // Extra items to render above and below

    let scrollTop = 0;

    const render = () => {
      const startIndex = Math.max(0, Math.floor(scrollTop / itemHeight) - buffer);
      const endIndex = Math.min(items.length, startIndex + visibleCount + buffer * 2);

      container.innerHTML = '';
      container.style.height = `${totalHeight}px`;
      container.style.position = 'relative';

      for (let i = startIndex; i < endIndex; i++) {
        const element = renderItem(items[i], i);
        element.style.position = 'absolute';
        element.style.top = `${i * itemHeight}px`;
        element.style.height = `${itemHeight}px`;
        container.appendChild(element);
      }
    };

    container.addEventListener('scroll', this.throttle(() => {
      scrollTop = container.scrollTop;
      render();
    }, 16)); // ~60fps

    render();
  }

  /**
   * Compress data for storage
   */
  async compressData(data) {
    const json = JSON.stringify(data);
    const encoder = new TextEncoder();
    const uint8Array = encoder.encode(json);
    
    const stream = new ReadableStream({
      start(controller) {
        controller.enqueue(uint8Array);
        controller.close();
      }
    });

    const compressedStream = stream.pipeThrough(new CompressionStream('gzip'));
    const chunks = [];
    
    for await (const chunk of compressedStream) {
      chunks.push(chunk);
    }

    const compressed = new Uint8Array(
      chunks.reduce((acc, chunk) => acc + chunk.length, 0)
    );
    
    let offset = 0;
    for (const chunk of chunks) {
      compressed.set(chunk, offset);
      offset += chunk.length;
    }

    return Array.from(compressed);
  }

  /**
   * Decompress data from storage
   */
  async decompressData(compressedArray) {
    const uint8Array = new Uint8Array(compressedArray);
    
    const stream = new ReadableStream({
      start(controller) {
        controller.enqueue(uint8Array);
        controller.close();
      }
    });

    const decompressedStream = stream.pipeThrough(new DecompressionStream('gzip'));
    const chunks = [];
    
    for await (const chunk of decompressedStream) {
      chunks.push(chunk);
    }

    const decompressed = new Uint8Array(
      chunks.reduce((acc, chunk) => acc + chunk.length, 0)
    );
    
    let offset = 0;
    for (const chunk of chunks) {
      decompressed.set(chunk, offset);
      offset += chunk.length;
    }

    const decoder = new TextDecoder();
    const json = decoder.decode(decompressed);
    return JSON.parse(json);
  }

  /**
   * Optimize image loading
   */
  optimizeImage(img, maxWidth = 800, maxHeight = 600) {
    return new Promise((resolve) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');

      const image = new Image();
      image.onload = () => {
        let width = image.width;
        let height = image.height;

        if (width > maxWidth) {
          height = (height * maxWidth) / width;
          width = maxWidth;
        }

        if (height > maxHeight) {
          width = (width * maxHeight) / height;
          height = maxHeight;
        }

        canvas.width = width;
        canvas.height = height;
        ctx.drawImage(image, 0, 0, width, height);

        canvas.toBlob((blob) => {
          resolve(blob);
        }, 'image/jpeg', 0.85);
      };

      image.src = img.src;
    });
  }

  /**
   * Track performance metrics
   */
  trackMetric(category, name, duration) {
    if (!this.metrics[category]) {
      this.metrics[category] = [];
    }

    this.metrics[category].push({
      name,
      duration,
      timestamp: Date.now()
    });

    // Keep only last 100 metrics per category
    if (this.metrics[category].length > 100) {
      this.metrics[category].shift();
    }
  }

  /**
   * Get performance report
   */
  getPerformanceReport() {
    const report = {};

    Object.keys(this.metrics).forEach(category => {
      const metrics = this.metrics[category];
      if (metrics.length === 0) {
        report[category] = { count: 0 };
        return;
      }

      const durations = metrics.map(m => m.duration);
      const sum = durations.reduce((a, b) => a + b, 0);
      const avg = sum / durations.length;
      const min = Math.min(...durations);
      const max = Math.max(...durations);

      report[category] = {
        count: metrics.length,
        average: avg.toFixed(2),
        min: min.toFixed(2),
        max: max.toFixed(2)
      };
    });

    return report;
  }

  /**
   * Clear performance metrics
   */
  clearMetrics() {
    this.metrics = {
      loadTimes: [],
      apiCalls: [],
      storageOperations: [],
      renderTimes: []
    };
  }

  /**
   * Create a performance monitor for async operations
   */
  async measureAsync(name, category, operation) {
    const start = performance.now();
    try {
      const result = await operation();
      const duration = performance.now() - start;
      this.trackMetric(category, name, duration);
      return result;
    } catch (error) {
      const duration = performance.now() - start;
      this.trackMetric(category, `${name} (failed)`, duration);
      throw error;
    }
  }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = PerformanceOptimizer;
}
