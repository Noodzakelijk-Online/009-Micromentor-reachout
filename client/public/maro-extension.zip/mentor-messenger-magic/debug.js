// debug.js - Core debugging functionality for Mentor Messenger Magic Extension

/**
 * Debug - Main debugging class for Mentor Messenger Magic
 * Provides logging, state inspection, network monitoring, and performance tracking
 */
class Debug {
  constructor() {
    this.enabled = false;
    this.logLevel = 'info'; // debug, info, warn, error
    this.maxLogs = 1000;
    this.persistLogs = true;
    this.timers = {};
    
    // Log levels with numeric values for comparison
    this.LOG_LEVELS = {
      debug: 0,
      info: 1,
      warn: 2,
      error: 3
    };
    
    // Initialize storage
    this.initializeStorage();
  }
  
  /**
   * Initialize debug storage
   */
  async initializeStorage() {
    try {
      // Get existing debug data
      const data = await chrome.storage.local.get('debugData');
      
      // Initialize if not exists
      if (!data.debugData) {
        const debugData = {
          logs: [],
          states: {},
          network: [],
          performance: {
            operations: {}
          },
          settings: {
            logLevel: this.logLevel,
            persistence: this.persistLogs,
            maxLogs: this.maxLogs,
            enabled: this.enabled
          }
        };
        
        await chrome.storage.local.set({ debugData });
      } else {
        // Load settings
        this.logLevel = data.debugData.settings.logLevel || this.logLevel;
        this.persistLogs = data.debugData.settings.persistence !== undefined ? 
          data.debugData.settings.persistence : this.persistLogs;
        this.maxLogs = data.debugData.settings.maxLogs || this.maxLogs;
        this.enabled = data.debugData.settings.enabled !== undefined ?
          data.debugData.settings.enabled : this.enabled;
      }
    } catch (error) {
      console.error('Error initializing debug storage:', error);
    }
  }
  
  /**
   * Enable debugging
   */
  async enable() {
    this.enabled = true;
    await this.updateSettings({ enabled: true });
    this.log('info', 'Debug mode enabled');
  }
  
  /**
   * Disable debugging
   */
  async disable() {
    this.enabled = false;
    await this.updateSettings({ enabled: false });
    this.log('info', 'Debug mode disabled');
  }
  
  /**
   * Update debug settings
   * @param {Object} settings - Settings to update
   */
  async updateSettings(settings) {
    try {
      const data = await chrome.storage.local.get('debugData');
      if (data.debugData) {
        const updatedSettings = {
          ...data.debugData.settings,
          ...settings
        };
        
        // Update local settings
        if (settings.logLevel !== undefined) this.logLevel = settings.logLevel;
        if (settings.persistence !== undefined) this.persistLogs = settings.persistence;
        if (settings.maxLogs !== undefined) this.maxLogs = settings.maxLogs;
        if (settings.enabled !== undefined) this.enabled = settings.enabled;
        
        // Save to storage
        await chrome.storage.local.set({
          debugData: {
            ...data.debugData,
            settings: updatedSettings
          }
        });
        
        return true;
      }
      return false;
    } catch (error) {
      console.error('Error updating debug settings:', error);
      return false;
    }
  }
  
  /**
   * Log a message with specified level
   * @param {string} level - Log level (debug, info, warn, error)
   * @param {string} message - Log message
   * @param {Object} context - Additional context data
   * @param {string} component - Component name
   */
  async log(level, message, context = {}, component = 'general') {
    // Skip if debugging is disabled or log level is too low
    if (!this.enabled || this.LOG_LEVELS[level] < this.LOG_LEVELS[this.logLevel]) {
      return;
    }
    
    try {
      // Create log entry
      const logEntry = {
        timestamp: new Date().toISOString(),
        level,
        component,
        message,
        context
      };
      
      // Add stack trace for errors
      if (level === 'error') {
        logEntry.stackTrace = new Error().stack;
      }
      
      // Always log to console
      this.logToConsole(logEntry);
      
      // Skip storage if persistence is disabled
      if (!this.persistLogs) {
        return;
      }
      
      // Get existing logs
      const data = await chrome.storage.local.get('debugData');
      if (!data.debugData) {
        await this.initializeStorage();
        return this.log(level, message, context, component);
      }
      
      // Add new log
      const logs = data.debugData.logs || [];
      logs.push(logEntry);
      
      // Trim logs if exceeding max
      while (logs.length > this.maxLogs) {
        logs.shift();
      }
      
      // Save updated logs
      await chrome.storage.local.set({
        debugData: {
          ...data.debugData,
          logs
        }
      });
    } catch (error) {
      console.error('Error logging debug message:', error);
    }
  }
  
  /**
   * Log to console with appropriate styling
   * @param {Object} logEntry - Log entry to display
   */
  logToConsole(logEntry) {
    const { level, component, message, context, timestamp } = logEntry;
    
    // Format timestamp
    const time = new Date(timestamp).toLocaleTimeString();
    
    // Define styles for different log levels
    const styles = {
      debug: 'color: #9e9e9e',
      info: 'color: #2196f3',
      warn: 'color: #ff9800; font-weight: bold',
      error: 'color: #f44336; font-weight: bold'
    };
    
    // Log with appropriate console method and styling
    const style = styles[level] || styles.info;
    const prefix = `%c[${time}][${level.toUpperCase()}][${component}]`;
    
    switch (level) {
      case 'debug':
        console.debug(prefix, style, message, context);
        break;
      case 'warn':
        console.warn(prefix, style, message, context);
        break;
      case 'error':
        console.error(prefix, style, message, context);
        break;
      case 'info':
      default:
        console.info(prefix, style, message, context);
    }
    
    // Log stack trace separately for errors
    if (level === 'error' && logEntry.stackTrace) {
      console.groupCollapsed('Stack trace');
      console.trace(logEntry.stackTrace);
      console.groupEnd();
    }
  }
  
  /**
   * Debug level log
   * @param {string} message - Log message
   * @param {Object} context - Additional context data
   * @param {string} component - Component name
   */
  debug(message, context = {}, component = 'general') {
    return this.log('debug', message, context, component);
  }
  
  /**
   * Info level log
   * @param {string} message - Log message
   * @param {Object} context - Additional context data
   * @param {string} component - Component name
   */
  info(message, context = {}, component = 'general') {
    return this.log('info', message, context, component);
  }
  
  /**
   * Warning level log
   * @param {string} message - Log message
   * @param {Object} context - Additional context data
   * @param {string} component - Component name
   */
  warn(message, context = {}, component = 'general') {
    return this.log('warn', message, context, component);
  }
  
  /**
   * Error level log
   * @param {string} message - Log message
   * @param {Object} context - Additional context data
   * @param {string} component - Component name
   */
  error(message, context = {}, component = 'general') {
    return this.log('error', message, context, component);
  }
  
  /**
   * Create a component-specific logger
   * @param {string} componentName - Name of the component
   * @returns {Object} Component logger
   */
  component(componentName) {
    return {
      debug: (message, context = {}) => this.debug(message, context, componentName),
      info: (message, context = {}) => this.info(message, context, componentName),
      warn: (message, context = {}) => this.warn(message, context, componentName),
      error: (message, context = {}) => this.error(message, context, componentName),
      captureState: (stateName, stateData) => this.captureState(componentName, stateName, stateData)
    };
  }
  
  /**
   * Capture component state for debugging
   * @param {string} componentName - Component name
   * @param {string} stateName - State name
   * @param {any} stateData - State data to capture
   */
  async captureState(componentName, stateName, stateData) {
    if (!this.enabled) return;
    
    try {
      // Get existing debug data
      const data = await chrome.storage.local.get('debugData');
      if (!data.debugData) {
        await this.initializeStorage();
        return this.captureState(componentName, stateName, stateData);
      }
      
      // Create or update component state
      const states = data.debugData.states || {};
      if (!states[componentName]) {
        states[componentName] = {};
      }
      
      // Add timestamp to state data
      const stateWithMeta = {
        data: stateData,
        capturedAt: new Date().toISOString()
      };
      
      // Update state
      states[componentName][stateName] = stateWithMeta;
      
      // Save updated states
      await chrome.storage.local.set({
        debugData: {
          ...data.debugData,
          states
        }
      });
      
      this.debug(`State captured: ${componentName}.${stateName}`, { size: JSON.stringify(stateData).length }, 'state');
    } catch (error) {
      console.error('Error capturing state:', error);
    }
  }
  
  /**
   * Log network request
   * @param {string} url - Request URL
   * @param {string} method - HTTP method
   * @param {Object} requestData - Request data
   */
  async logRequest(url, method, requestData = {}) {
    if (!this.enabled) return;
    
    try {
      // Create network entry
      const networkEntry = {
        timestamp: new Date().toISOString(),
        url,
        method,
        requestData,
        startTime: Date.now()
      };
      
      // Get existing network logs
      const data = await chrome.storage.local.get('debugData');
      if (!data.debugData) {
        await this.initializeStorage();
        return this.logRequest(url, method, requestData);
      }
      
      // Add new network entry
      const network = data.debugData.network || [];
      network.push(networkEntry);
      
      // Trim if too many entries
      while (network.length > this.maxLogs) {
        network.shift();
      }
      
      // Save updated network logs
      await chrome.storage.local.set({
        debugData: {
          ...data.debugData,
          network
        }
      });
      
      this.debug(`Network request: ${method} ${url}`, requestData, 'network');
      
      // Return the timestamp to correlate with response
      return networkEntry.timestamp;
    } catch (error) {
      console.error('Error logging network request:', error);
    }
  }
  
  /**
   * Log network response
   * @param {string} timestamp - Request timestamp for correlation
   * @param {number} status - HTTP status code
   * @param {Object} responseData - Response data
   */
  async logResponse(timestamp, status, responseData = {}) {
    if (!this.enabled) return;
    
    try {
      // Get existing network logs
      const data = await chrome.storage.local.get('debugData');
      if (!data.debugData) {
        await this.initializeStorage();
        return;
      }
      
      // Find matching request
      const network = data.debugData.network || [];
      const index = network.findIndex(entry => entry.timestamp === timestamp);
      
      if (index >= 0) {
        // Update with response data
        network[index].responseStatus = status;
        network[index].responseData = responseData;
        network[index].duration = Date.now() - new Date(network[index].startTime).getTime();
        
        // Save updated network logs
        await chrome.storage.local.set({
          debugData: {
            ...data.debugData,
            network
          }
        });
        
        const level = status >= 400 ? 'error' : 'debug';
        this[level](`Network response: ${status}`, { 
          url: network[index].url, 
          duration: network[index].duration,
          response: responseData
        }, 'network');
      }
    } catch (error) {
      console.error('Error logging network response:', error);
    }
  }
  
  /**
   * Start performance timer
   * @param {string} operationName - Name of the operation to time
   */
  startTimer(operationName) {
    if (!this.enabled) return;
    
    this.timers[operationName] = Date.now();
    this.debug(`Timer started: ${operationName}`, {}, 'performance');
  }
  
  /**
   * End performance timer and record results
   * @param {string} operationName - Name of the operation to time
   */
  async endTimer(operationName) {
    if (!this.enabled || !this.timers[operationName]) return;
    
    try {
      const startTime = this.timers[operationName];
      const duration = Date.now() - startTime;
      
      // Clear timer
      delete this.timers[operationName];
      
      // Get existing performance data
      const data = await chrome.storage.local.get('debugData');
      if (!data.debugData) {
        await this.initializeStorage();
        return;
      }
      
      // Get or create operation stats
      const performance = data.debugData.performance || { operations: {} };
      const operations = performance.operations || {};
      const operation = operations[operationName] || {
        count: 0,
        totalDuration: 0,
        averageDuration: 0,
        minDuration: Infinity,
        maxDuration: 0
      };
      
      // Update stats
      operation.count++;
      operation.totalDuration += duration;
      operation.averageDuration = operation.totalDuration / operation.count;
      operation.minDuration = Math.min(operation.minDuration, duration);
      operation.maxDuration = Math.max(operation.maxDuration, duration);
      
      // Save updated performance data
      operations[operationName] = operation;
      await chrome.storage.local.set({
        debugData: {
          ...data.debugData,
          performance: {
            ...performance,
            operations
          }
        }
      });
      
      this.debug(`Timer ended: ${operationName}`, { 
        duration,
        average: operation.averageDuration,
        count: operation.count
      }, 'performance');
      
      return duration;
    } catch (error) {
      console.error('Error ending timer:', error);
    }
  }
  
  /**
   * Clear all debug data
   */
  async clearData() {
    try {
      // Get current settings
      const data = await chrome.storage.local.get('debugData');
      const settings = data.debugData?.settings || {
        logLevel: this.logLevel,
        persistence: this.persistLogs,
        maxLogs: this.maxLogs,
        enabled: this.enabled
      };
      
      // Reset debug data but keep settings
      await chrome.storage.local.set({
        debugData: {
          logs: [],
          states: {},
          network: [],
          performance: {
            operations: {}
          },
          settings
        }
      });
      
      this.info('Debug data cleared', {}, 'system');
      return true;
    } catch (error) {
      console.error('Error clearing debug data:', error);
      return false;
    }
  }
  
  /**
   * Get all debug logs
   * @param {Object} filters - Optional filters for logs
   * @returns {Array} Filtered logs
   */
  async getLogs(filters = {}) {
    try {
      const data = await chrome.storage.local.get('debugData');
      if (!data.debugData) {
        return [];
      }
      
      let logs = data.debugData.logs || [];
      
      // Apply filters
      if (filters.level) {
        const levelValue = this.LOG_LEVELS[filters.level];
        logs = logs.filter(log => this.LOG_LEVELS[log.level] >= levelValue);
      }
      
      if (filters.component) {
        logs = logs.filter(log => log.component === filters.component);
      }
      
      if (filters.search) {
        const searchLower = filters.search.toLowerCase();
        logs = logs.filter(log => 
          log.message.toLowerCase().includes(searchLower) || 
          JSON.stringify(log.context).toLowerCase().includes(searchLower)
        );
      }
      
      if (filters.startTime) {
        logs = logs.filter(log => new Date(log.timestamp) >= new Date(filters.startTime));
      }
      
      if (filters.endTime) {
        logs = logs.filter(log => new Date(log.timestamp) <= new Date(filters.endTime));
      }
      
      // Apply limit
      if (filters.limit && logs.length > filters.limit) {
        logs = logs.slice(-filters.limit);
      }
      
      return logs;
    } catch (error) {
      console.error('Error getting debug logs:', error);
      return [];
    }
  }
  
  /**
   * Get state data
   * @param {string} componentName - Optional component name filter
   * @param {string} stateName - Optional state name filter
   * @returns {Object} State data
   */
  async getState(componentName, stateName) {
    try {
      const data = await chrome.storage.local.get('debugData');
      if (!data.debugData) {
        return {};
      }
      
      const states = data.debugData.states || {};
      
      if (componentName && stateName) {
        return states[componentName]?.[stateName] || null;
      }
      
      if (componentName) {
        return states[componentName] || {};
      }
      
      return states;
    } catch (error) {
      console.error('Error getting state data:', error);
      return {};
    }
  }
  
  /**
   * Get network logs
   * @param {Object} filters - Optional filters
   * @returns {Array} Network logs
   */
  async getNetworkLogs(filters = {}) {
    try {
      const data = await chrome.storage.local.get('debugData');
      if (!data.debugData) {
        return [];
      }
      
      let network = data.debugData.network || [];
      
      // Apply filters
      if (filters.url) {
        network = network.filter(entry => entry.url.includes(filters.url));
      }
      
      if (filters.method) {
        network = network.filter(entry => entry.method === filters.method);
      }
      
      if (filters.status) {
        network = network.filter(entry => entry.responseStatus === filters.status);
      }
      
      if (filters.minDuration) {
        network = network.filter(entry => entry.duration >= filters.minDuration);
      }
      
      // Apply limit
      if (filters.limit && network.length > filters.limit) {
        network = network.slice(-filters.limit);
      }
      
      return network;
    } catch (error) {
      console.error('Error getting network logs:', error);
      return [];
    }
  }
  
  /**
   * Get performance data
   * @param {string} operationName - Optional operation name filter
   * @returns {Object} Performance data
   */
  async getPerformanceData(operationName) {
    try {
      const data = await chrome.storage.local.get('debugData');
      if (!data.debugData) {
        return {};
      }
      
      const performance = data.debugData.performance || { operations: {} };
      
      if (operationName) {
        return performance.operations[operationName] || null;
      }
      
      return performance;
    } catch (error) {
      console.error('Error getting performance data:', error);
      return {};
    }
  }
  
  /**
   * Export debug data as JSON
   * @returns {string} JSON string of debug data
   */
  async exportData() {
    try {
      const data = await chrome.storage.local.get('debugData');
      if (!data.debugData) {
        return '{}';
      }
      
      // Add export metadata
      const exportData = {
        ...data.debugData,
        exportMeta: {
          timestamp: new Date().toISOString(),
          version: chrome.runtime.getManifest().version
        }
      };
      
      return JSON.stringify(exportData, null, 2);
    } catch (error) {
      console.error('Error exporting debug data:', error);
      return '{}';
    }
  }
  
  /**
   * Import debug data from JSON
   * @param {string} jsonData - JSON string of debug data
   * @returns {boolean} Success status
   */
  async importData(jsonData) {
    try {
      // Parse JSON
      const importedData = JSON.parse(jsonData);
      
      // Validate basic structure
      if (!importedData || !importedData.logs || !importedData.settings) {
        throw new Error('Invalid debug data format');
      }
      
      // Get current settings
      const data = await chrome.storage.local.get('debugData');
      const currentSettings = data.debugData?.settings || {
        logLevel: this.logLevel,
        persistence: this.persistLogs,
        maxLogs: this.maxLogs,
        enabled: this.enabled
      };
      
      // Merge with current settings
      await chrome.storage.local.set({
        debugData: {
          ...importedData,
          settings: {
            ...importedData.settings,
            enabled: currentSettings.enabled // Keep current enabled state
          }
        }
      });
      
      // Update local settings
      this.logLevel = importedData.settings.logLevel || this.logLevel;
      this.persistLogs = importedData.settings.persistence !== undefined ? 
        importedData.settings.persistence : this.persistLogs;
      this.maxLogs = importedData.settings.maxLogs || this.maxLogs;
      
      this.info('Debug data imported', {
        logs: importedData.logs.length,
        states: Object.keys(importedData.states || {}).length,
        network: (importedData.network || []).length
      }, 'system');
      
      return true;
    } catch (error) {
      console.error('Error importing debug data:', error);
      return false;
    }
  }
}

// Create and export singleton instance
const debug = new Debug();
export default debug;
