/**
 * Secure Storage Module
 * Handles encryption and secure storage of sensitive user data
 */

class SecureStorage {
  constructor() {
    this.encryptionKey = null;
    this.initialized = false;
  }

  /**
   * Initialize secure storage with encryption key
   */
  async initialize() {
    if (this.initialized) {
      return;
    }

    // Generate or retrieve encryption key
    const stored = await chrome.storage.local.get(['encryptionKey']);
    
    if (stored.encryptionKey) {
      this.encryptionKey = await this.importKey(stored.encryptionKey);
    } else {
      this.encryptionKey = await this.generateKey();
      const exportedKey = await this.exportKey(this.encryptionKey);
      await chrome.storage.local.set({ encryptionKey: exportedKey });
    }

    this.initialized = true;
  }

  /**
   * Generate a new encryption key
   */
  async generateKey() {
    return await crypto.subtle.generateKey(
      {
        name: 'AES-GCM',
        length: 256
      },
      true,
      ['encrypt', 'decrypt']
    );
  }

  /**
   * Export key for storage
   */
  async exportKey(key) {
    const exported = await crypto.subtle.exportKey('raw', key);
    return Array.from(new Uint8Array(exported));
  }

  /**
   * Import key from storage
   */
  async importKey(keyData) {
    const keyArray = new Uint8Array(keyData);
    return await crypto.subtle.importKey(
      'raw',
      keyArray,
      {
        name: 'AES-GCM',
        length: 256
      },
      true,
      ['encrypt', 'decrypt']
    );
  }

  /**
   * Encrypt data
   */
  async encrypt(data) {
    if (!this.initialized) {
      await this.initialize();
    }

    const encoder = new TextEncoder();
    const dataBuffer = encoder.encode(JSON.stringify(data));
    
    // Generate a random IV
    const iv = crypto.getRandomValues(new Uint8Array(12));
    
    // Encrypt the data
    const encrypted = await crypto.subtle.encrypt(
      {
        name: 'AES-GCM',
        iv: iv
      },
      this.encryptionKey,
      dataBuffer
    );

    // Combine IV and encrypted data
    const combined = new Uint8Array(iv.length + encrypted.byteLength);
    combined.set(iv, 0);
    combined.set(new Uint8Array(encrypted), iv.length);

    // Convert to base64 for storage
    return btoa(String.fromCharCode(...combined));
  }

  /**
   * Decrypt data
   */
  async decrypt(encryptedData) {
    if (!this.initialized) {
      await this.initialize();
    }

    try {
      // Convert from base64
      const combined = Uint8Array.from(atob(encryptedData), c => c.charCodeAt(0));
      
      // Extract IV and encrypted data
      const iv = combined.slice(0, 12);
      const data = combined.slice(12);

      // Decrypt the data
      const decrypted = await crypto.subtle.decrypt(
        {
          name: 'AES-GCM',
          iv: iv
        },
        this.encryptionKey,
        data
      );

      // Convert back to string and parse JSON
      const decoder = new TextDecoder();
      const decryptedString = decoder.decode(decrypted);
      return JSON.parse(decryptedString);
    } catch (error) {
      console.error('Decryption failed:', error);
      throw new Error('Failed to decrypt data');
    }
  }

  /**
   * Store encrypted data
   */
  async setSecure(key, value) {
    const encrypted = await this.encrypt(value);
    await chrome.storage.local.set({ [key]: encrypted });
  }

  /**
   * Retrieve and decrypt data
   */
  async getSecure(key) {
    const stored = await chrome.storage.local.get([key]);
    if (!stored[key]) {
      return null;
    }
    return await this.decrypt(stored[key]);
  }

  /**
   * Remove secure data
   */
  async removeSecure(key) {
    await chrome.storage.local.remove([key]);
  }

  /**
   * Store authentication token securely
   */
  async setAuthToken(token) {
    await this.setSecure('authToken', token);
  }

  /**
   * Retrieve authentication token
   */
  async getAuthToken() {
    return await this.getSecure('authToken');
  }

  /**
   * Store API credentials securely
   */
  async setCredentials(credentials) {
    await this.setSecure('credentials', credentials);
  }

  /**
   * Retrieve API credentials
   */
  async getCredentials() {
    return await this.getSecure('credentials');
  }

  /**
   * Clear all secure data
   */
  async clearAll() {
    const keys = ['authToken', 'credentials', 'encryptionKey'];
    await chrome.storage.local.remove(keys);
    this.initialized = false;
    this.encryptionKey = null;
  }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = SecureStorage;
}
