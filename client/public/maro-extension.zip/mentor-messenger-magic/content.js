// content.js - Content script for Mentor Messenger Magic Extension

// Constants
const MICROMENTOR_SELECTORS = {
  // These selectors would need to be updated based on actual MicroMentor DOM structure
  MESSAGE_COMPOSE: 'textarea[name="message"], div[role="textbox"]',
  SEND_BUTTON: 'button[type="submit"], button:contains("Send")',
  PROFILE_NAME: '.profile-name, .user-name',
  PROFILE_EXPERTISE: '.expertise, .skills',
  CONVERSATION_THREAD: '.conversation-thread, .message-list',
  MESSAGE_ITEM: '.message-item, .message',
  RECIPIENT_LIST: '.recipient-list, .contact-list'
};

// Global state
let templates = [];
let settings = {};
let currentProfile = null;

// Initialize when DOM is fully loaded
document.addEventListener('DOMContentLoaded', initialize);

// Initialize the content script
async function initialize() {
  console.log('Mentor Messenger Magic content script initialized');
  
  // Check if we're on a MicroMentor page
  if (!isMicroMentorPage()) {
    console.log('Not a MicroMentor page, exiting');
    return;
  }
  
  // Load templates and settings
  await loadTemplatesAndSettings();
  
  // Detect page type and initialize appropriate features
  detectPageTypeAndInitialize();
  
  // Set up message listener for communication with background script
  setupMessageListener();
  
  // Inject UI elements
  injectUI();
}

// Check if current page is a MicroMentor page
function isMicroMentorPage() {
  const hostname = window.location.hostname;
  return hostname.includes('micromentor.org');
}

// Load templates and settings from storage
async function loadTemplatesAndSettings() {
  try {
    // Get templates
    const templatesResponse = await chrome.runtime.sendMessage({
      action: 'getTemplates'
    });
    
    if (templatesResponse && templatesResponse.success) {
      templates = templatesResponse.templates;
      console.log(`Loaded ${templates.length} templates`);
    }
    
    // Get settings
    const settingsResponse = await chrome.runtime.sendMessage({
      action: 'getSettings'
    });
    
    if (settingsResponse && settingsResponse.success) {
      settings = settingsResponse.settings;
      console.log('Loaded settings', settings);
    }
  } catch (error) {
    console.error('Error loading templates and settings:', error);
  }
}

// Detect page type and initialize appropriate features
function detectPageTypeAndInitialize() {
  // Check for message compose page
  const composeElement = document.querySelector(MICROMENTOR_SELECTORS.MESSAGE_COMPOSE);
  if (composeElement) {
    console.log('Detected message compose page');
    initializeMessageCompose(composeElement);
  }
  
  // Check for profile page
  const profileNameElement = document.querySelector(MICROMENTOR_SELECTORS.PROFILE_NAME);
  if (profileNameElement) {
    console.log('Detected profile page');
    initializeProfilePage(profileNameElement);
  }
  
  // Check for conversation page
  const conversationElement = document.querySelector(MICROMENTOR_SELECTORS.CONVERSATION_THREAD);
  if (conversationElement) {
    console.log('Detected conversation page');
    initializeConversationPage(conversationElement);
  }
  
  // Check for recipient list page
  const recipientListElement = document.querySelector(MICROMENTOR_SELECTORS.RECIPIENT_LIST);
  if (recipientListElement) {
    console.log('Detected recipient list page');
    initializeRecipientListPage(recipientListElement);
  }
}

// Set up message listener for communication with background script
function setupMessageListener() {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('Content script received message:', message);
    
    // Route message to appropriate handler
    switch (message.action) {
      case 'executeMessageSend':
        handleExecuteMessageSend(message.data, sendResponse);
        return true; // Keep channel open for async response
        
      case 'extractProfile':
        handleExtractProfile(sendResponse);
        return true;
        
      case 'extractConversation':
        handleExtractConversation(sendResponse);
        return true;
        
      case 'refreshTemplates':
        handleRefreshTemplates(sendResponse);
        return true;
        
      default:
        console.log('Unknown action:', message.action);
        sendResponse({ success: false, error: 'Unknown action' });
    }
  });
}

// Initialize message compose functionality
function initializeMessageCompose(composeElement) {
  // Extract recipient information if available
  extractRecipientInfo();
  
  // Add template selector button
  if (settings.ui && settings.ui.showTemplateButton) {
    addTemplateSelector(composeElement);
  }
  
  // Add automation button if enabled
  if (settings.automation && settings.automation.enableQueueProcessing) {
    addAutomationButton(composeElement);
  }
}

// Initialize profile page functionality
function initializeProfilePage(profileNameElement) {
  // Extract profile data
  const profile = extractProfileData();
  
  // Save profile to storage
  if (profile && profile.id) {
    saveProfile(profile);
  }
  
  // Add quick message button
  addQuickMessageButton(profileNameElement);
}

// Initialize conversation page functionality
function initializeConversationPage(conversationElement) {
  // Extract conversation data
  const conversation = extractConversationData();
  
  // Save conversation to storage
  if (conversation && conversation.participantId) {
    saveConversation(conversation);
  }
  
  // Add template selector to reply box
  const replyBox = document.querySelector(MICROMENTOR_SELECTORS.MESSAGE_COMPOSE);
  if (replyBox) {
    addTemplateSelector(replyBox);
  }
}

// Initialize recipient list page functionality
function initializeRecipientListPage(recipientListElement) {
  // Add batch message button
  addBatchMessageButton(recipientListElement);
}

// Extract recipient information from the page
function extractRecipientInfo() {
  try {
    // This would need to be customized based on MicroMentor's DOM structure
    // For now, we'll use a placeholder implementation
    
    // Try to find recipient name
    const recipientNameElement = document.querySelector('.recipient-name, .to-field');
    if (recipientNameElement) {
      const recipientName = recipientNameElement.textContent.trim();
      
      // Try to find recipient ID (this would depend on MicroMentor's implementation)
      // For example, it might be in a data attribute or in the URL
      let recipientId = '';
      
      // Check URL for ID
      const urlMatch = window.location.href.match(/user\/(\d+)/);
      if (urlMatch && urlMatch[1]) {
        recipientId = urlMatch[1];
      }
      
      // If we found both name and ID, save as current profile
      if (recipientName && recipientId) {
        currentProfile = {
          id: recipientId,
          name: recipientName,
          source: 'compose-page'
        };
        
        console.log('Extracted recipient info:', currentProfile);
      }
    }
  } catch (error) {
    console.error('Error extracting recipient info:', error);
  }
}

// Extract profile data from profile page
function extractProfileData() {
  try {
    // This would need to be customized based on MicroMentor's DOM structure
    // For now, we'll use a placeholder implementation
    
    // Try to find profile name
    const nameElement = document.querySelector(MICROMENTOR_SELECTORS.PROFILE_NAME);
    if (!nameElement) return null;
    
    const name = nameElement.textContent.trim();
    
    // Try to find profile ID from URL
    let id = '';
    const urlMatch = window.location.href.match(/profile\/(\d+)/);
    if (urlMatch && urlMatch[1]) {
      id = urlMatch[1];
    }
    
    // If no ID in URL, generate one from name
    if (!id && name) {
      id = 'profile-' + name.toLowerCase().replace(/[^a-z0-9]/g, '-');
    }
    
    // Try to find expertise
    const expertiseElement = document.querySelector(MICROMENTOR_SELECTORS.PROFILE_EXPERTISE);
    const expertise = expertiseElement ? expertiseElement.textContent.trim() : '';
    
    // Create profile object
    const profile = {
      id,
      name,
      expertise,
      url: window.location.href,
      extractedAt: new Date().toISOString()
    };
    
    console.log('Extracted profile data:', profile);
    
    // Save as current profile
    currentProfile = profile;
    
    return profile;
  } catch (error) {
    console.error('Error extracting profile data:', error);
    return null;
  }
}

// Extract conversation data from conversation page
function extractConversationData() {
  try {
    // This would need to be customized based on MicroMentor's DOM structure
    // For now, we'll use a placeholder implementation
    
    // Try to find conversation participant
    const participantElement = document.querySelector('.conversation-with, .participant-name');
    if (!participantElement) return null;
    
    const participantName = participantElement.textContent.trim();
    
    // Try to find participant ID from URL
    let participantId = '';
    const urlMatch = window.location.href.match(/conversation\/(\d+)/);
    if (urlMatch && urlMatch[1]) {
      participantId = urlMatch[1];
    }
    
    // If no ID in URL, generate one from name
    if (!participantId && participantName) {
      participantId = 'conversation-' + participantName.toLowerCase().replace(/[^a-z0-9]/g, '-');
    }
    
    // Try to find messages
    const messageElements = document.querySelectorAll(MICROMENTOR_SELECTORS.MESSAGE_ITEM);
    const messages = [];
    
    messageElements.forEach((element, index) => {
      // Determine if message is from user or participant
      const isFromUser = element.classList.contains('from-me') || 
                         element.classList.contains('outgoing') ||
                         element.querySelector('.from-me, .outgoing');
      
      // Get message content
      const contentElement = element.querySelector('.message-content, .content');
      const content = contentElement ? contentElement.textContent.trim() : '';
      
      // Get timestamp if available
      const timestampElement = element.querySelector('.timestamp, .time');
      const timestamp = timestampElement ? timestampElement.textContent.trim() : '';
      
      // Add message to array
      if (content) {
        messages.push({
          content,
          sender: isFromUser ? 'user' : 'participant',
          timestamp: timestamp || new Date().toISOString(),
          index
        });
      }
    });
    
    // Create conversation object
    const conversation = {
      participantId,
      participantName,
      messages,
      url: window.location.href,
      extractedAt: new Date().toISOString()
    };
    
    console.log('Extracted conversation data:', conversation);
    
    return conversation;
  } catch (error) {
    console.error('Error extracting conversation data:', error);
    return null;
  }
}

// Save profile to storage
async function saveProfile(profile) {
  try {
    const response = await chrome.runtime.sendMessage({
      action: 'saveProfile',
      data: profile
    });
    
    console.log('Save profile response:', response);
    return response && response.success;
  } catch (error) {
    console.error('Error saving profile:', error);
    return false;
  }
}

// Save conversation to storage
async function saveConversation(conversation) {
  try {
    const response = await chrome.runtime.sendMessage({
      action: 'saveConversation',
      data: conversation
    });
    
    console.log('Save conversation response:', response);
    return response && response.success;
  } catch (error) {
    console.error('Error saving conversation:', error);
    return false;
  }
}

// Add template selector button to compose element
function addTemplateSelector(composeElement) {
  // Create template button
  const templateButton = document.createElement('button');
  templateButton.textContent = 'Templates';
  templateButton.className = 'mmm-template-button';
  templateButton.title = 'Insert a message template';
  
  // Position the button near the compose element
  positionElementNear(templateButton, composeElement);
  
  // Add click event listener
  templateButton.addEventListener('click', () => {
    showTemplateSelector(composeElement);
  });
  
  // Add to page
  document.body.appendChild(templateButton);
}

// Add automation button to compose element
function addAutomationButton(composeElement) {
  // Create automation button
  const automationButton = document.createElement('button');
  automationButton.textContent = 'Auto-Send';
  automationButton.className = 'mmm-automation-button';
  automationButton.title = 'Configure automated sending';
  
  // Position the button near the compose element
  positionElementNear(automationButton, composeElement, 60); // Offset to not overlap template button
  
  // Add click event listener
  automationButton.addEventListener('click', () => {
    showAutomationOptions(composeElement);
  });
  
  // Add to page
  document.body.appendChild(automationButton);
}

// Add quick message button to profile element
function addQuickMessageButton(profileElement) {
  // Only add if we have a valid profile
  if (!currentProfile || !currentProfile.id) return;
  
  // Create quick message button
  const quickMessageButton = document.createElement('button');
  quickMessageButton.textContent = 'Quick Message';
  quickMessageButton.className = 'mmm-quick-message-button';
  quickMessageButton.title = 'Send a quick message using templates';
  
  // Position the button near the profile element
  positionElementNear(quickMessageButton, profileElement);
  
  // Add click event listener
  quickMessageButton.addEventListener('click', () => {
    showQuickMessageDialog(currentProfile);
  });
  
  // Add to page
  document.body.appendChild(quickMessageButton);
}

// Add batch message button to recipient list
function addBatchMessageButton(recipientListElement) {
  // Create batch message button
  const batchMessageButton = document.createElement('button');
  batchMessageButton.textContent = 'Batch Message';
  batchMessageButton.className = 'mmm-batch-message-button';
  batchMessageButton.title = 'Send messages to multiple recipients';
  
  // Position the button near the recipient list
  positionElementNear(batchMessageButton, recipientListElement);
  
  // Add click event listener
  batchMessageButton.addEventListener('click', () => {
    showBatchMessageDialog();
  });
  
  // Add to page
  document.body.appendChild(batchMessageButton);
}

// Position an element near another element
function positionElementNear(element, targetElement, offsetX = 0) {
  // Get target element position
  const targetRect = targetElement.getBoundingClientRect();
  
  // Set element position
  element.style.position = 'absolute';
  element.style.zIndex = '9999';
  
  // Position to the right of target
  element.style.left = `${window.scrollX + targetRect.right + 10 + offsetX}px`;
  element.style.top = `${window.scrollY + targetRect.top}px`;
}

// Show template selector dialog
function showTemplateSelector(composeElement) {
  // Create template selector container
  const container = document.createElement('div');
  container.className = 'mmm-template-selector';
  
  // Add header
  const header = document.createElement('div');
  header.className = 'mmm-template-header';
  header.textContent = 'Select a Template';
  container.appendChild(header);
  
  // Add close button
  const closeButton = document.createElement('button');
  closeButton.textContent = '×';
  closeButton.className = 'mmm-close-button';
  closeButton.addEventListener('click', () => {
    document.body.removeChild(container);
  });
  header.appendChild(closeButton);
  
  // Add template list
  const templateList = document.createElement('div');
  templateList.className = 'mmm-template-list';
  
  // Group templates by category
  const templatesByCategory = {};
  templates.forEach(template => {
    const category = template.category || 'General';
    if (!templatesByCategory[category]) {
      templatesByCategory[category] = [];
    }
    templatesByCategory[category].push(template);
  });
  
  // Add templates by category
  Object.entries(templatesByCategory).forEach(([category, categoryTemplates]) => {
    // Add category header
    const categoryHeader = document.createElement('div');
    categoryHeader.className = 'mmm-category-header';
    categoryHeader.textContent = category;
    templateList.appendChild(categoryHeader);
    
    // Add templates
    categoryTemplates.forEach(template => {
      const templateItem = document.createElement('div');
      templateItem.className = 'mmm-template-item';
      templateItem.textContent = template.name;
      
      // Add click event to insert template
      templateItem.addEventListener('click', () => {
        insertTemplate(template, composeElement);
        document.body.removeChild(container);
      });
      
      templateList.appendChild(templateItem);
    });
  });
  
  container.appendChild(templateList);
  
  // Position the container
  const composeRect = composeElement.getBoundingClientRect();
  container.style.position = 'absolute';
  container.style.zIndex = '10000';
  container.style.left = `${window.scrollX + composeRect.left}px`;
  container.style.top = `${window.scrollY + composeRect.bottom + 10}px`;
  
  // Add to page
  document.body.appendChild(container);
}

// Show automation options dialog
function showAutomationOptions(composeElement) {
  // Create automation options container
  const container = document.createElement('div');
  container.className = 'mmm-automation-options';
  
  // Add header
  const header = document.createElement('div');
  header.className = 'mmm-automation-header';
  header.textContent = 'Automation Options';
  container.appendChild(header);
  
  // Add close button
  const closeButton = document.createElement('button');
  closeButton.textContent = '×';
  closeButton.className = 'mmm-close-button';
  closeButton.addEventListener('click', () => {
    document.body.removeChild(container);
  });
  header.appendChild(closeButton);
  
  // Add options
  const optionsContainer = document.createElement('div');
  optionsContainer.className = 'mmm-options-container';
  
  // Add send now option
  const sendNowOption = document.createElement('div');
  sendNowOption.className = 'mmm-option-item';
  sendNowOption.textContent = 'Send message now';
  sendNowOption.addEventListener('click', () => {
    sendMessageNow(composeElement);
    document.body.removeChild(container);
  });
  optionsContainer.appendChild(sendNowOption);
  
  // Add queue option
  const queueOption = document.createElement('div');
  queueOption.className = 'mmm-option-item';
  queueOption.textContent = 'Add to message queue';
  queueOption.addEventListener('click', () => {
    queueMessage(composeElement);
    document.body.removeChild(container);
  });
  optionsContainer.appendChild(queueOption);
  
  container.appendChild(optionsContainer);
  
  // Position the container
  const composeRect = composeElement.getBoundingClientRect();
  container.style.position = 'absolute';
  container.style.zIndex = '10000';
  container.style.left = `${window.scrollX + composeRect.left}px`;
  container.style.top = `${window.scrollY + composeRect.bottom + 10}px`;
  
  // Add to page
  document.body.appendChild(container);
}

// Show quick message dialog
function showQuickMessageDialog(profile) {
  // Create quick message container
  const container = document.createElement('div');
  container.className = 'mmm-quick-message';
  
  // Add header
  const header = document.createElement('div');
  header.className = 'mmm-quick-message-header';
  header.textContent = `Quick Message to ${profile.name}`;
  container.appendChild(header);
  
  // Add close button
  const closeButton = document.createElement('button');
  closeButton.textContent = '×';
  closeButton.className = 'mmm-close-button';
  closeButton.addEventListener('click', () => {
    document.body.removeChild(container);
  });
  header.appendChild(closeButton);
  
  // Add template selector
  const templateSelector = document.createElement('select');
  templateSelector.className = 'mmm-template-select';
  
  // Add default option
  const defaultOption = document.createElement('option');
  defaultOption.value = '';
  defaultOption.textContent = 'Select a template...';
  templateSelector.appendChild(defaultOption);
  
  // Add templates
  templates.forEach(template => {
    const option = document.createElement('option');
    option.value = template.id;
    option.textContent = `${template.name} (${template.category || 'General'})`;
    templateSelector.appendChild(option);
  });
  
  container.appendChild(templateSelector);
  
  // Add message preview
  const preview = document.createElement('div');
  preview.className = 'mmm-message-preview';
  preview.textContent = 'Select a template to preview the message.';
  container.appendChild(preview);
  
  // Update preview when template changes
  templateSelector.addEventListener('change', () => {
    const selectedTemplate = templates.find(t => t.id === templateSelector.value);
    if (selectedTemplate) {
      preview.textContent = personalizeTemplate(selectedTemplate.content, profile);
    } else {
      preview.textContent = 'Select a template to preview the message.';
    }
  });
  
  // Add send button
  const sendButton = document.createElement('button');
  sendButton.className = 'mmm-send-button';
  sendButton.textContent = 'Send Message';
  sendButton.addEventListener('click', () => {
    const selectedTemplate = templates.find(t => t.id === templateSelector.value);
    if (selectedTemplate) {
      sendQuickMessage(profile, selectedTemplate);
      document.body.removeChild(container);
    } else {
      alert('Please select a template first.');
    }
  });
  container.appendChild(sendButton);
  
  // Position the container in the center of the viewport
  container.style.position = 'fixed';
  container.style.zIndex = '10000';
  container.style.left = '50%';
  container.style.top = '50%';
  container.style.transform = 'translate(-50%, -50%)';
  
  // Add to page
  document.body.appendChild(container);
}

// Show batch message dialog
function showBatchMessageDialog() {
  // Create batch message container
  const container = document.createElement('div');
  container.className = 'mmm-batch-message';
  
  // Add header
  const header = document.createElement('div');
  header.className = 'mmm-batch-message-header';
  header.textContent = 'Batch Message';
  container.appendChild(header);
  
  // Add close button
  const closeButton = document.createElement('button');
  closeButton.textContent = '×';
  closeButton.className = 'mmm-close-button';
  closeButton.addEventListener('click', () => {
    document.body.removeChild(container);
  });
  header.appendChild(closeButton);
  
  // Add recipient selector
  const recipientSelector = document.createElement('div');
  recipientSelector.className = 'mmm-recipient-selector';
  recipientSelector.textContent = 'Scanning for recipients...';
  container.appendChild(recipientSelector);
  
  // Add template selector
  const templateSelector = document.createElement('select');
  templateSelector.className = 'mmm-template-select';
  
  // Add default option
  const defaultOption = document.createElement('option');
  defaultOption.value = '';
  defaultOption.textContent = 'Select a template...';
  templateSelector.appendChild(defaultOption);
  
  // Add templates
  templates.forEach(template => {
    const option = document.createElement('option');
    option.value = template.id;
    option.textContent = `${template.name} (${template.category || 'General'})`;
    templateSelector.appendChild(option);
  });
  
  container.appendChild(templateSelector);
  
  // Add send button
  const sendButton = document.createElement('button');
  sendButton.className = 'mmm-send-button';
  sendButton.textContent = 'Send to Selected';
  sendButton.disabled = true; // Disabled until recipients are selected
  container.appendChild(sendButton);
  
  // Position the container in the center of the viewport
  container.style.position = 'fixed';
  container.style.zIndex = '10000';
  container.style.left = '50%';
  container.style.top = '50%';
  container.style.transform = 'translate(-50%, -50%)';
  
  // Add to page
  document.body.appendChild(container);
  
  // Scan for recipients
  setTimeout(() => {
    scanForRecipients(recipientSelector, sendButton);
  }, 100);
}

// Scan for recipients on the current page
function scanForRecipients(recipientSelector, sendButton) {
  try {
    // Clear the selector
    recipientSelector.innerHTML = '';
    
    // Find recipient elements
    const recipientElements = document.querySelectorAll('.user-item, .mentor-item, .entrepreneur-item');
    
    if (recipientElements.length === 0) {
      recipientSelector.textContent = 'No recipients found on this page.';
      return;
    }
    
    // Create recipient list
    const recipientList = document.createElement('div');
    recipientList.className = 'mmm-recipient-list';
    
    // Add recipients
    let foundRecipients = 0;
    
    recipientElements.forEach((element, index) => {
      // Try to extract recipient info
      const nameElement = element.querySelector('.name, .user-name');
      if (!nameElement) return;
      
      const name = nameElement.textContent.trim();
      
      // Generate ID if not available
      let id = element.getAttribute('data-id') || element.getAttribute('id');
      if (!id) {
        id = `recipient-${index}-${name.toLowerCase().replace(/[^a-z0-9]/g, '-')}`;
      }
      
      // Create recipient item
      const recipientItem = document.createElement('div');
      recipientItem.className = 'mmm-recipient-item';
      
      // Add checkbox
      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.value = id;
      checkbox.setAttribute('data-name', name);
      recipientItem.appendChild(checkbox);
      
      // Add name
      const nameSpan = document.createElement('span');
      nameSpan.textContent = name;
      recipientItem.appendChild(nameSpan);
      
      // Add to list
      recipientList.appendChild(recipientItem);
      foundRecipients++;
      
      // Enable send button when at least one recipient is checked
      checkbox.addEventListener('change', () => {
        const checkedRecipients = recipientList.querySelectorAll('input[type="checkbox"]:checked');
        sendButton.disabled = checkedRecipients.length === 0;
      });
    });
    
    // Add recipient list to selector
    if (foundRecipients > 0) {
      recipientSelector.appendChild(recipientList);
      
      // Add select all checkbox
      const selectAllContainer = document.createElement('div');
      selectAllContainer.className = 'mmm-select-all';
      
      const selectAllCheckbox = document.createElement('input');
      selectAllCheckbox.type = 'checkbox';
      selectAllCheckbox.id = 'mmm-select-all';
      selectAllContainer.appendChild(selectAllCheckbox);
      
      const selectAllLabel = document.createElement('label');
      selectAllLabel.htmlFor = 'mmm-select-all';
      selectAllLabel.textContent = `Select All (${foundRecipients})`;
      selectAllContainer.appendChild(selectAllLabel);
      
      // Add select all functionality
      selectAllCheckbox.addEventListener('change', () => {
        const checkboxes = recipientList.querySelectorAll('input[type="checkbox"]');
        checkboxes.forEach(checkbox => {
          checkbox.checked = selectAllCheckbox.checked;
        });
        
        sendButton.disabled = !selectAllCheckbox.checked;
      });
      
      recipientSelector.insertBefore(selectAllContainer, recipientList);
    } else {
      recipientSelector.textContent = 'No recipients found on this page.';
    }
  } catch (error) {
    console.error('Error scanning for recipients:', error);
    recipientSelector.textContent = 'Error scanning for recipients.';
  }
}

// Insert template into compose element
function insertTemplate(template, composeElement) {
  try {
    // Get current profile if available
    const profile = currentProfile || {};
    
    // Personalize template
    const personalizedContent = personalizeTemplate(template.content, profile);
    
    // Insert into compose element
    if (composeElement.tagName.toLowerCase() === 'textarea') {
      // For textarea elements
      composeElement.value = personalizedContent;
      
      // Trigger input event to update any listeners
      composeElement.dispatchEvent(new Event('input', { bubbles: true }));
    } else {
      // For contenteditable elements
      composeElement.innerHTML = personalizedContent.replace(/\n/g, '<br>');
      
      // Trigger input event to update any listeners
      composeElement.dispatchEvent(new Event('input', { bubbles: true }));
    }
    
    // Track template usage
    trackTemplateUsage(template.id);
  } catch (error) {
    console.error('Error inserting template:', error);
    alert('Error inserting template. Please try again.');
  }
}

// Personalize template with profile data
function personalizeTemplate(templateContent, profile) {
  try {
    // Replace profile placeholders
    let content = templateContent;
    
    if (profile) {
      // Replace name
      content = content.replace(/{{name}}/g, profile.name || '[Name]');
      
      // Replace expertise
      content = content.replace(/{{expertise}}/g, profile.expertise || '[Expertise]');
    }
    
    // Replace user placeholders
    // In a real implementation, this would use user data from settings
    content = content.replace(/{{user_name}}/g, 'Your Name');
    content = content.replace(/{{project}}/g, 'my project');
    content = content.replace(/{{specific_topic}}/g, 'specific topic');
    content = content.replace(/{{interest_area}}/g, 'area of interest');
    content = content.replace(/{{topic}}/g, 'our topic');
    content = content.replace(/{{specific_point}}/g, 'specific point');
    content = content.replace(/{{benefit}}/g, 'make progress');
    content = content.replace(/{{suggestion}}/g, 'your suggestion');
    
    return content;
  } catch (error) {
    console.error('Error personalizing template:', error);
    return templateContent;
  }
}

// Track template usage
async function trackTemplateUsage(templateId) {
  try {
    // Update resource usage
    await chrome.runtime.sendMessage({
      action: 'updateResourceUsage',
      data: { metric: 'templatesUsed' }
    });
    
    console.log('Tracked template usage:', templateId);
  } catch (error) {
    console.error('Error tracking template usage:', error);
  }
}

// Send message now
async function sendMessageNow(composeElement) {
  try {
    // Check if we have a recipient
    if (!currentProfile || !currentProfile.id) {
      alert('Could not determine message recipient. Please try again.');
      return;
    }
    
    // Get message content
    let content = '';
    if (composeElement.tagName.toLowerCase() === 'textarea') {
      content = composeElement.value;
    } else {
      content = composeElement.innerText;
    }
    
    if (!content.trim()) {
      alert('Please enter a message before sending.');
      return;
    }
    
    // Confirm if required by settings
    if (settings.automation && settings.automation.confirmBeforeSend) {
      if (!confirm(`Send this message to ${currentProfile.name}?`)) {
        return;
      }
    }
    
    // Find send button
    const sendButton = document.querySelector(MICROMENTOR_SELECTORS.SEND_BUTTON);
    
    if (!sendButton) {
      alert('Could not find send button. Please send the message manually.');
      return;
    }
    
    // Click the send button
    sendButton.click();
    
    // Track message sent
    await chrome.runtime.sendMessage({
      action: 'updateResourceUsage',
      data: { metric: 'messagesSent' }
    });
    
    // Save to conversation history
    await chrome.runtime.sendMessage({
      action: 'saveConversation',
      data: {
        participantId: currentProfile.id,
        participantName: currentProfile.name,
        messages: [
          {
            content,
            sender: 'user',
            timestamp: new Date().toISOString()
          }
        ]
      }
    });
    
    console.log('Message sent successfully');
  } catch (error) {
    console.error('Error sending message:', error);
    alert('Error sending message. Please try again or send manually.');
  }
}

// Queue message for later sending
async function queueMessage(composeElement) {
  try {
    // Check if we have a recipient
    if (!currentProfile || !currentProfile.id) {
      alert('Could not determine message recipient. Please try again.');
      return;
    }
    
    // Get message content
    let content = '';
    if (composeElement.tagName.toLowerCase() === 'textarea') {
      content = composeElement.value;
    } else {
      content = composeElement.innerText;
    }
    
    if (!content.trim()) {
      alert('Please enter a message before queueing.');
      return;
    }
    
    // Queue the message
    const response = await chrome.runtime.sendMessage({
      action: 'queueMessage',
      data: {
        recipientId: currentProfile.id,
        recipientName: currentProfile.name,
        content,
        url: window.location.href
      }
    });
    
    if (response && response.success) {
      alert(`Message queued successfully. Position in queue: ${response.queuePosition}`);
    } else {
      alert('Error queueing message. Please try again.');
    }
  } catch (error) {
    console.error('Error queueing message:', error);
    alert('Error queueing message. Please try again.');
  }
}

// Send quick message
async function sendQuickMessage(profile, template) {
  try {
    // Personalize template
    const content = personalizeTemplate(template.content, profile);
    
    // Send message
    const response = await chrome.runtime.sendMessage({
      action: 'sendMessage',
      data: {
        recipientId: profile.id,
        recipientName: profile.name,
        content,
        templateId: template.id
      }
    });
    
    if (response && response.success) {
      alert(`Message sent successfully to ${profile.name}.`);
    } else {
      alert(`Error sending message: ${response ? response.error : 'Unknown error'}`);
    }
  } catch (error) {
    console.error('Error sending quick message:', error);
    alert('Error sending message. Please try again.');
  }
}

// Handle executing message send from background script
async function handleExecuteMessageSend(data, sendResponse) {
  try {
    console.log('Executing message send:', data);
    
    // This would need to navigate to the appropriate page and send the message
    // For now, we'll just simulate success
    
    // In a real implementation, this would:
    // 1. Navigate to the message compose page for the recipient
    // 2. Fill in the message content
    // 3. Click the send button
    
    // Simulate success
    setTimeout(() => {
      sendResponse({ success: true });
    }, 500);
  } catch (error) {
    console.error('Error executing message send:', error);
    sendResponse({ success: false, error: error.message });
  }
  
  return true; // Keep channel open for async response
}

// Handle extracting profile from background script
function handleExtractProfile(sendResponse) {
  try {
    const profile = extractProfileData();
    sendResponse({ success: true, profile });
  } catch (error) {
    console.error('Error extracting profile:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// Handle extracting conversation from background script
function handleExtractConversation(sendResponse) {
  try {
    const conversation = extractConversationData();
    sendResponse({ success: true, conversation });
  } catch (error) {
    console.error('Error extracting conversation:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// Handle refreshing templates from background script
async function handleRefreshTemplates(sendResponse) {
  try {
    await loadTemplatesAndSettings();
    sendResponse({ success: true });
  } catch (error) {
    console.error('Error refreshing templates:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// Inject CSS styles
function injectUI() {
  // Create style element
  const style = document.createElement('style');
  style.textContent = `
    /* Mentor Messenger Magic styles */
    .mmm-template-button,
    .mmm-automation-button,
    .mmm-quick-message-button,
    .mmm-batch-message-button {
      background-color: #4a86e8;
      color: white;
      border: none;
      border-radius: 4px;
      padding: 5px 10px;
      font-size: 12px;
      cursor: pointer;
      margin: 5px;
    }
    
    .mmm-template-selector,
    .mmm-automation-options,
    .mmm-quick-message,
    .mmm-batch-message {
      background-color: white;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      padding: 10px;
      min-width: 300px;
      max-width: 500px;
    }
    
    .mmm-template-header,
    .mmm-automation-header,
    .mmm-quick-message-header,
    .mmm-batch-message-header {
      font-weight: bold;
      margin-bottom: 10px;
      padding-bottom: 5px;
      border-bottom: 1px solid #eee;
      position: relative;
    }
    
    .mmm-close-button {
      position: absolute;
      right: 0;
      top: 0;
      background: none;
      border: none;
      font-size: 16px;
      cursor: pointer;
      color: #999;
    }
    
    .mmm-template-list {
      max-height: 300px;
      overflow-y: auto;
    }
    
    .mmm-category-header {
      font-weight: bold;
      margin-top: 10px;
      color: #666;
    }
    
    .mmm-template-item,
    .mmm-option-item {
      padding: 5px;
      cursor: pointer;
      border-radius: 3px;
    }
    
    .mmm-template-item:hover,
    .mmm-option-item:hover {
      background-color: #f0f0f0;
    }
    
    .mmm-message-preview {
      margin: 10px 0;
      padding: 10px;
      border: 1px solid #eee;
      border-radius: 4px;
      background-color: #f9f9f9;
      max-height: 200px;
      overflow-y: auto;
    }
    
    .mmm-send-button {
      background-color: #4a86e8;
      color: white;
      border: none;
      border-radius: 4px;
      padding: 8px 15px;
      font-size: 14px;
      cursor: pointer;
      width: 100%;
      margin-top: 10px;
    }
    
    .mmm-send-button:disabled {
      background-color: #ccc;
      cursor: not-allowed;
    }
    
    .mmm-template-select {
      width: 100%;
      padding: 5px;
      border-radius: 3px;
      border: 1px solid #ccc;
    }
    
    .mmm-recipient-selector {
      margin: 10px 0;
      max-height: 200px;
      overflow-y: auto;
    }
    
    .mmm-recipient-item {
      padding: 5px;
      display: flex;
      align-items: center;
    }
    
    .mmm-recipient-item input {
      margin-right: 10px;
    }
    
    .mmm-select-all {
      padding: 5px;
      margin-bottom: 5px;
      font-weight: bold;
      display: flex;
      align-items: center;
    }
    
    .mmm-select-all input {
      margin-right: 10px;
    }
  `;
  
  // Add to page
  document.head.appendChild(style);
}
