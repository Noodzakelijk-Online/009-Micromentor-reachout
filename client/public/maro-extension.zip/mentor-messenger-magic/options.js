// options.js - Script for the options page

document.addEventListener('DOMContentLoaded', initialize);

// Initialize the options page
async function initialize() {
  console.log('Initializing options page');
  
  // Load templates
  await loadTemplates();
  
  // Load settings
  await loadSettings();
  
  // Set up event listeners
  setupEventListeners();
}

// Load templates
async function loadTemplates() {
  try {
    const response = await chrome.runtime.sendMessage({
      action: 'getTemplates'
    });
    
    if (response && response.success) {
      const { templates } = response;
      
      // Get template container
      const templateContainer = document.getElementById('template-container');
      templateContainer.innerHTML = '';
      
      if (templates.length === 0) {
        templateContainer.innerHTML = '<div class="empty-state">No templates found. Create your first template to get started.</div>';
        return;
      }
      
      // Group templates by category
      const templatesByCategory = {};
      templates.forEach(template => {
        const category = template.category || 'General';
        if (!templatesByCategory[category]) {
          templatesByCategory[category] = [];
        }
        templatesByCategory[category].push(template);
      });
      
      // Add templates to container by category
      Object.entries(templatesByCategory).forEach(([category, categoryTemplates]) => {
        // Add category header
        const categoryHeader = document.createElement('div');
        categoryHeader.className = 'category-header';
        categoryHeader.textContent = category;
        templateContainer.appendChild(categoryHeader);
        
        // Add templates
        categoryTemplates.forEach(template => {
          const templateCard = createTemplateCard(template);
          templateContainer.appendChild(templateCard);
        });
      });
    } else {
      document.getElementById('template-container').innerHTML = '<div class="empty-state">Error loading templates</div>';
    }
  } catch (error) {
    console.error('Error loading templates:', error);
    document.getElementById('template-container').innerHTML = '<div class="empty-state">Error loading templates</div>';
  }
}

// Create template card
function createTemplateCard(template) {
  const card = document.createElement('div');
  card.className = 'template-card';
  card.setAttribute('data-id', template.id);
  
  const header = document.createElement('div');
  header.className = 'template-header';
  
  const title = document.createElement('div');
  title.className = 'template-title';
  title.textContent = template.name;
  header.appendChild(title);
  
  const actions = document.createElement('div');
  actions.className = 'template-actions';
  
  const editButton = document.createElement('button');
  editButton.className = 'action-button edit';
  editButton.innerHTML = '<i class="icon-edit"></i> Edit';
  editButton.addEventListener('click', (e) => {
    e.stopPropagation();
    openTemplateEditor(template);
  });
  actions.appendChild(editButton);
  
  const deleteButton = document.createElement('button');
  deleteButton.className = 'action-button delete';
  deleteButton.innerHTML = '<i class="icon-delete"></i> Delete';
  deleteButton.addEventListener('click', (e) => {
    e.stopPropagation();
    deleteTemplate(template.id);
  });
  actions.appendChild(deleteButton);
  
  header.appendChild(actions);
  card.appendChild(header);
  
  const content = document.createElement('div');
  content.className = 'template-content';
  content.textContent = template.content;
  card.appendChild(content);
  
  const footer = document.createElement('div');
  footer.className = 'template-footer';
  
  const category = document.createElement('div');
  category.className = 'template-category';
  category.textContent = template.category || 'General';
  footer.appendChild(category);
  
  card.appendChild(footer);
  
  // Add click event to expand/collapse
  card.addEventListener('click', () => {
    card.classList.toggle('expanded');
  });
  
  return card;
}

// Open template editor
function openTemplateEditor(template = null) {
  // Get editor elements
  const editor = document.getElementById('template-editor');
  const editorTitle = document.getElementById('editor-title');
  const templateId = document.getElementById('template-id');
  const templateName = document.getElementById('template-name');
  const templateCategory = document.getElementById('template-category');
  const templateContent = document.getElementById('template-content');
  
  // Set editor title
  editorTitle.textContent = template ? 'Edit Template' : 'Create Template';
  
  // Set form values
  templateId.value = template ? template.id : '';
  templateName.value = template ? template.name : '';
  templateCategory.value = template ? (template.category || 'General') : 'General';
  templateContent.value = template ? template.content : '';
  
  // Show editor
  editor.classList.add('visible');
  
  // Focus on name field
  templateName.focus();
}

// Save template
async function saveTemplate() {
  try {
    // Get form values
    const id = document.getElementById('template-id').value;
    const name = document.getElementById('template-name').value;
    const category = document.getElementById('template-category').value;
    const content = document.getElementById('template-content').value;
    
    // Validate
    if (!name) {
      alert('Please enter a template name');
      return;
    }
    
    if (!content) {
      alert('Please enter template content');
      return;
    }
    
    // Create template object
    const template = {
      id: id || null, // null for new templates
      name,
      category: category || 'General',
      content
    };
    
    // Send to background script
    const response = await chrome.runtime.sendMessage({
      action: 'saveTemplate',
      data: template
    });
    
    if (response && response.success) {
      // Close editor
      document.getElementById('template-editor').classList.remove('visible');
      
      // Reload templates
      await loadTemplates();
      
      // Show success message
      showNotification('Template saved successfully');
    } else {
      alert('Error saving template: ' + (response ? response.error : 'Unknown error'));
    }
  } catch (error) {
    console.error('Error saving template:', error);
    alert('Error saving template. Please try again.');
  }
}

// Delete template
async function deleteTemplate(id) {
  try {
    if (!confirm('Are you sure you want to delete this template? This cannot be undone.')) {
      return;
    }
    
    const response = await chrome.runtime.sendMessage({
      action: 'deleteTemplate',
      data: { id }
    });
    
    if (response && response.success) {
      // Reload templates
      await loadTemplates();
      
      // Show success message
      showNotification('Template deleted successfully');
    } else {
      alert('Error deleting template: ' + (response ? response.error : 'Unknown error'));
    }
  } catch (error) {
    console.error('Error deleting template:', error);
    alert('Error deleting template. Please try again.');
  }
}

// Load settings
async function loadSettings() {
  try {
    const response = await chrome.runtime.sendMessage({
      action: 'getSettings'
    });
    
    if (response && response.success) {
      const { settings } = response;
      
      // Update settings form
      document.getElementById('confirm-before-send').checked = settings.automation.confirmBeforeSend;
      document.getElementById('enable-queue-processing').checked = settings.automation.enableQueueProcessing;
      document.getElementById('messages-per-hour').value = settings.rateLimit.messagesPerHour;
      document.getElementById('messages-per-day').value = settings.rateLimit.messagesPerDay;
      document.getElementById('show-template-button').checked = settings.ui.showTemplateButton;
      document.getElementById('enable-inline-preview').checked = settings.ui.enableInlinePreview;
      
      // Update notification settings
      document.getElementById('notifications-enabled').checked = settings.notifications.enabled;
      document.getElementById('new-messages-notification').checked = settings.notifications.newMessages;
      document.getElementById('queue-updates-notification').checked = settings.notifications.queueUpdates;
      document.getElementById('resource-alerts-notification').checked = settings.notifications.resourceAlerts;
    }
  } catch (error) {
    console.error('Error loading settings:', error);
    showNotification('Error loading settings', 'error');
  }
}

// Save settings
async function saveSettings() {
  try {
    const settings = {
      automation: {
        confirmBeforeSend: document.getElementById('confirm-before-send').checked,
        enableQueueProcessing: document.getElementById('enable-queue-processing').checked
      },
      rateLimit: {
        messagesPerHour: parseInt(document.getElementById('messages-per-hour').value, 10),
        messagesPerDay: parseInt(document.getElementById('messages-per-day').value, 10)
      },
      ui: {
        showTemplateButton: document.getElementById('show-template-button').checked,
        enableInlinePreview: document.getElementById('enable-inline-preview').checked
      },
      notifications: {
        enabled: document.getElementById('notifications-enabled').checked,
        newMessages: document.getElementById('new-messages-notification').checked,
        queueUpdates: document.getElementById('queue-updates-notification').checked,
        resourceAlerts: document.getElementById('resource-alerts-notification').checked
      }
    };
    
    const response = await chrome.runtime.sendMessage({
      action: 'updateSettings',
      data: settings
    });
    
    if (response && response.success) {
      showNotification('Settings saved successfully');
    } else {
      alert('Error saving settings: ' + (response ? response.error : 'Unknown error'));
    }
  } catch (error) {
    console.error('Error saving settings:', error);
    alert('Error saving settings. Please try again.');
  }
}

// Reset settings
async function resetSettings() {
  try {
    if (!confirm('Reset all settings to default values?')) {
      return;
    }
    
    const response = await chrome.runtime.sendMessage({
      action: 'resetSettings'
    });
    
    if (response && response.success) {
      // Reload settings
      await loadSettings();
      
      // Show success message
      showNotification('Settings reset successfully');
    } else {
      alert('Error resetting settings: ' + (response ? response.error : 'Unknown error'));
    }
  } catch (error) {
    console.error('Error resetting settings:', error);
    alert('Error resetting settings. Please try again.');
  }
}

// Show notification
function showNotification(message, type = 'success') {
  const notification = document.getElementById('notification');
  notification.textContent = message;
  notification.className = `notification ${type}`;
  notification.classList.add('visible');
  
  // Hide after 3 seconds
  setTimeout(() => {
    notification.classList.remove('visible');
  }, 3000);
}

// Set up event listeners
function setupEventListeners() {
  // Template actions
  document.getElementById('add-template-button').addEventListener('click', () => {
    openTemplateEditor();
  });
  
  document.getElementById('save-template-button').addEventListener('click', saveTemplate);
  
  document.getElementById('cancel-template-button').addEventListener('click', () => {
    document.getElementById('template-editor').classList.remove('visible');
  });
  
  // Settings actions
  document.getElementById('save-settings-button').addEventListener('click', saveSettings);
  
  document.getElementById('reset-settings-button').addEventListener('click', resetSettings);
  
  // Tab switching
  const tabs = document.querySelectorAll('.tab');
  const tabContents = document.querySelectorAll('.tab-content');
  
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      // Remove active class from all tabs and contents
      tabs.forEach(t => t.classList.remove('active'));
      tabContents.forEach(c => c.classList.remove('active'));
      
      // Add active class to clicked tab
      tab.classList.add('active');
      
      // Get tab name and activate corresponding content
      const tabName = tab.getAttribute('data-tab');
      document.getElementById(`${tabName}-content`).classList.add('active');
    });
  });
  
  // Close editor when clicking outside
  document.getElementById('template-editor').addEventListener('click', (e) => {
    if (e.target.id === 'template-editor') {
      document.getElementById('template-editor').classList.remove('visible');
    }
  });
}
