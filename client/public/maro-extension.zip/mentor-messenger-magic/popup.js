// popup.js - Script for the popup UI

// DOM elements
const elements = {
  // Tabs
  tabs: document.querySelectorAll('.tab'),
  tabContents: document.querySelectorAll('.tab-content'),
  
  // Dashboard
  messagesSent: document.getElementById('messages-sent'),
  templatesUsed: document.getElementById('templates-used'),
  dailyUsageBar: document.getElementById('daily-usage-bar'),
  recentActivity: document.getElementById('recent-activity'),
  refreshDashboard: document.getElementById('refresh-dashboard'),
  viewOptions: document.getElementById('view-options'),
  
  // Queue
  queueCount: document.getElementById('queue-count'),
  messageQueue: document.getElementById('message-queue'),
  processQueue: document.getElementById('process-queue'),
  clearQueue: document.getElementById('clear-queue'),
  
  // Templates
  templateCount: document.getElementById('template-count'),
  templateList: document.getElementById('template-list'),
  addTemplate: document.getElementById('add-template'),
  manageTemplates: document.getElementById('manage-templates'),
  
  // Settings
  confirmBeforeSend: document.getElementById('confirm-before-send'),
  enableQueueProcessing: document.getElementById('enable-queue-processing'),
  messagesPerHour: document.getElementById('messages-per-hour'),
  messagesPerDay: document.getElementById('messages-per-day'),
  saveSettings: document.getElementById('save-settings'),
  resetSettings: document.getElementById('reset-settings')
};

// Initialize popup
document.addEventListener('DOMContentLoaded', initialize);

// Initialize the popup
async function initialize() {
  console.log('Initializing popup');
  
  // Set up tab switching
  setupTabs();
  
  // Load data for initial tab
  await loadDashboardData();
  
  // Set up event listeners
  setupEventListeners();
}

// Set up tab switching
function setupTabs() {
  elements.tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      // Remove active class from all tabs and contents
      elements.tabs.forEach(t => t.classList.remove('active'));
      elements.tabContents.forEach(c => c.classList.remove('active'));
      
      // Add active class to clicked tab
      tab.classList.add('active');
      
      // Get tab name and activate corresponding content
      const tabName = tab.getAttribute('data-tab');
      document.getElementById(`${tabName}-tab`).classList.add('active');
      
      // Load data for the selected tab
      loadTabData(tabName);
    });
  });
}

// Load data for a specific tab
async function loadTabData(tabName) {
  switch (tabName) {
    case 'dashboard':
      await loadDashboardData();
      break;
    case 'queue':
      await loadQueueData();
      break;
    case 'templates':
      await loadTemplatesData();
      break;
    case 'settings':
      await loadSettingsData();
      break;
  }
}

// Load dashboard data
async function loadDashboardData() {
  try {
    // Get resource usage
    const resourceResponse = await chrome.runtime.sendMessage({
      action: 'getResourceUsage'
    });
    
    if (resourceResponse && resourceResponse.success) {
      const { resourceUsage } = resourceResponse;
      
      // Update stats
      elements.messagesSent.textContent = resourceUsage.messagesSent;
      elements.templatesUsed.textContent = resourceUsage.templatesUsed;
      
      // Update usage bar (assuming daily limit from settings)
      const settingsResponse = await chrome.runtime.sendMessage({
        action: 'getSettings'
      });
      
      if (settingsResponse && settingsResponse.success) {
        const { settings } = settingsResponse;
        const dailyLimit = settings.rateLimit.messagesPerDay;
        const usagePercentage = (resourceUsage.messagesSent / dailyLimit) * 100;
        elements.dailyUsageBar.style.width = `${Math.min(usagePercentage, 100)}%`;
      }
      
      // Load recent activity (conversations)
      await loadRecentActivity();
    }
  } catch (error) {
    console.error('Error loading dashboard data:', error);
  }
}

// Load recent activity
async function loadRecentActivity() {
  try {
    // Get conversations
    const response = await chrome.runtime.sendMessage({
      action: 'getConversations',
      data: { limit: 5 }
    });
    
    if (response && response.success && response.conversations) {
      const { conversations } = response;
      
      // Clear container
      elements.recentActivity.innerHTML = '';
      
      if (Object.keys(conversations).length === 0) {
        elements.recentActivity.innerHTML = '<div class="empty-state">No recent activity</div>';
        return;
      }
      
      // Sort conversations by last update
      const sortedConversations = Object.values(conversations).sort((a, b) => {
        return new Date(b.updatedAt) - new Date(a.updatedAt);
      }).slice(0, 5);
      
      // Add conversations to container
      sortedConversations.forEach(conversation => {
        const lastMessage = conversation.messages[conversation.messages.length - 1];
        
        const activityItem = document.createElement('div');
        activityItem.className = 'queue-item';
        
        const header = document.createElement('div');
        header.className = 'queue-item-header';
        
        const recipient = document.createElement('div');
        recipient.className = 'queue-item-recipient';
        recipient.textContent = conversation.participantName || 'Unknown Recipient';
        header.appendChild(recipient);
        
        const timestamp = document.createElement('div');
        timestamp.className = 'queue-item-status';
        
        // Format timestamp
        const messageDate = new Date(lastMessage.timestamp);
        const now = new Date();
        const diffMs = now - messageDate;
        const diffMins = Math.floor(diffMs / 60000);
        const diffHours = Math.floor(diffMins / 60);
        const diffDays = Math.floor(diffHours / 24);
        
        if (diffDays > 0) {
          timestamp.textContent = `${diffDays}d ago`;
        } else if (diffHours > 0) {
          timestamp.textContent = `${diffHours}h ago`;
        } else if (diffMins > 0) {
          timestamp.textContent = `${diffMins}m ago`;
        } else {
          timestamp.textContent = 'Just now';
        }
        
        header.appendChild(timestamp);
        activityItem.appendChild(header);
        
        const content = document.createElement('div');
        content.className = 'queue-item-content';
        content.textContent = lastMessage.content;
        activityItem.appendChild(content);
        
        elements.recentActivity.appendChild(activityItem);
      });
    } else {
      elements.recentActivity.innerHTML = '<div class="empty-state">No recent activity</div>';
    }
  } catch (error) {
    console.error('Error loading recent activity:', error);
    elements.recentActivity.innerHTML = '<div class="empty-state">Error loading activity</div>';
  }
}

// Load queue data
async function loadQueueData() {
  try {
    // Get message queue
    const response = await chrome.runtime.sendMessage({
      action: 'getMessageQueue'
    });
    
    if (response && response.success) {
      const { queue } = response;
      
      // Update queue count
      elements.queueCount.textContent = queue.length;
      
      // Clear container
      elements.messageQueue.innerHTML = '';
      
      if (queue.length === 0) {
        elements.messageQueue.innerHTML = '<div class="empty-state">No messages in queue</div>';
        return;
      }
      
      // Add queue items to container
      queue.forEach((item, index) => {
        const queueItem = document.createElement('div');
        queueItem.className = 'queue-item';
        queueItem.setAttribute('data-id', index);
        
        const header = document.createElement('div');
        header.className = 'queue-item-header';
        
        const recipient = document.createElement('div');
        recipient.className = 'queue-item-recipient';
        recipient.textContent = item.recipientName || 'Unknown Recipient';
        header.appendChild(recipient);
        
        const status = document.createElement('div');
        status.className = `queue-item-status ${item.status}`;
        status.textContent = item.status.charAt(0).toUpperCase() + item.status.slice(1);
        header.appendChild(status);
        
        queueItem.appendChild(header);
        
        const content = document.createElement('div');
        content.className = 'queue-item-content';
        content.textContent = item.content;
        queueItem.appendChild(content);
        
        elements.messageQueue.appendChild(queueItem);
      });
    } else {
      elements.messageQueue.innerHTML = '<div class="empty-state">Error loading queue</div>';
    }
  } catch (error) {
    console.error('Error loading queue data:', error);
    elements.messageQueue.innerHTML = '<div class="empty-state">Error loading queue</div>';
  }
}

// Load templates data
async function loadTemplatesData() {
  try {
    // Get templates
    const response = await chrome.runtime.sendMessage({
      action: 'getTemplates'
    });
    
    if (response && response.success) {
      const { templates } = response;
      
      // Update template count
      elements.templateCount.textContent = templates.length;
      
      // Clear container
      elements.templateList.innerHTML = '';
      
      if (templates.length === 0) {
        elements.templateList.innerHTML = '<div class="empty-state">No templates found</div>';
        return;
      }
      
      // Group templates by category
      const templatesByCategory = {};
      templates.forEach(template => {
        const category = template.category || 'General';
        if (!templatesByCategory[category]) {
          templatesByCategory[category] = [];
        }
        templatesByCategory[category].push(template);
      });
      
      // Add templates to container by category
      Object.entries(templatesByCategory).forEach(([category, categoryTemplates]) => {
        // Add category header
        const categoryHeader = document.createElement('div');
        categoryHeader.className = 'section-title';
        categoryHeader.textContent = category;
        elements.templateList.appendChild(categoryHeader);
        
        // Add templates
        categoryTemplates.forEach(template => {
          const templateItem = document.createElement('div');
          templateItem.className = 'queue-item';
          templateItem.setAttribute('data-id', template.id);
          
          const header = document.createElement('div');
          header.className = 'queue-item-header';
          
          const name = document.createElement('div');
          name.className = 'queue-item-recipient';
          name.textContent = template.name;
          header.appendChild(name);
          
          templateItem.appendChild(header);
          
          const content = document.createElement('div');
          content.className = 'queue-item-content';
          content.textContent = template.content.substring(0, 100) + (template.content.length > 100 ? '...' : '');
          templateItem.appendChild(content);
          
          // Add click event to edit template
          templateItem.addEventListener('click', () => {
            openTemplateEditor(template);
          });
          
          elements.templateList.appendChild(templateItem);
        });
      });
    } else {
      elements.templateList.innerHTML = '<div class="empty-state">Error loading templates</div>';
    }
  } catch (error) {
    console.error('Error loading templates data:', error);
    elements.templateList.innerHTML = '<div class="empty-state">Error loading templates</div>';
  }
}

// Load settings data
async function loadSettingsData() {
  try {
    // Get settings
    const response = await chrome.runtime.sendMessage({
      action: 'getSettings'
    });
    
    if (response && response.success) {
      const { settings } = response;
      
      // Update settings form
      elements.confirmBeforeSend.checked = settings.automation.confirmBeforeSend;
      elements.enableQueueProcessing.checked = settings.automation.enableQueueProcessing;
      elements.messagesPerHour.value = settings.rateLimit.messagesPerHour;
      elements.messagesPerDay.value = settings.rateLimit.messagesPerDay;
    }
  } catch (error) {
    console.error('Error loading settings data:', error);
  }
}

// Set up event listeners
function setupEventListeners() {
  // Dashboard
  elements.refreshDashboard.addEventListener('click', loadDashboardData);
  elements.viewOptions.addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });
  
  // Queue
  elements.processQueue.addEventListener('click', processQueue);
  elements.clearQueue.addEventListener('click', clearQueue);
  
  // Templates
  elements.addTemplate.addEventListener('click', () => {
    openTemplateEditor();
  });
  elements.manageTemplates.addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });
  
  // Settings
  elements.saveSettings.addEventListener('click', saveSettings);
  elements.resetSettings.addEventListener('click', resetSettings);
}

// Process message queue
async function processQueue() {
  try {
    if (!confirm('Process all queued messages now?')) {
      return;
    }
    
    const response = await chrome.runtime.sendMessage({
      action: 'processQueue'
    });
    
    if (response && response.success) {
      alert(`Processed ${response.processed} messages. Success: ${response.succeeded}, Failed: ${response.failed}`);
      await loadQueueData();
    } else {
      alert('Error processing queue: ' + (response ? response.error : 'Unknown error'));
    }
  } catch (error) {
    console.error('Error processing queue:', error);
    alert('Error processing queue. Please try again.');
  }
}

// Clear message queue
async function clearQueue() {
  try {
    if (!confirm('Clear all queued messages? This cannot be undone.')) {
      return;
    }
    
    const response = await chrome.runtime.sendMessage({
      action: 'clearQueue'
    });
    
    if (response && response.success) {
      alert('Queue cleared successfully');
      await loadQueueData();
    } else {
      alert('Error clearing queue: ' + (response ? response.error : 'Unknown error'));
    }
  } catch (error) {
    console.error('Error clearing queue:', error);
    alert('Error clearing queue. Please try again.');
  }
}

// Open template editor
function openTemplateEditor(template = null) {
  // This would open the template editor in the options page
  // For now, we'll use a simple prompt-based editor
  
  try {
    const isNew = !template;
    
    // Get template name
    let name = '';
    if (isNew) {
      name = prompt('Enter template name:');
      if (!name) return;
    } else {
      name = prompt('Enter template name:', template.name);
      if (!name) return;
    }
    
    // Get template category
    let category = '';
    if (isNew) {
      category = prompt('Enter template category (or leave blank for "General"):');
      if (category === null) return;
      if (!category) category = 'General';
    } else {
      category = prompt('Enter template category:', template.category || 'General');
      if (category === null) return;
      if (!category) category = 'General';
    }
    
    // Get template content
    let content = '';
    if (isNew) {
      content = prompt('Enter template content:');
      if (!content) return;
    } else {
      content = prompt('Enter template content:', template.content);
      if (!content) return;
    }
    
    // Save template
    saveTemplate({
      id: template ? template.id : null,
      name,
      category,
      content
    });
  } catch (error) {
    console.error('Error in template editor:', error);
    alert('Error editing template. Please try again.');
  }
}

// Save template
async function saveTemplate(template) {
  try {
    const response = await chrome.runtime.sendMessage({
      action: 'saveTemplate',
      data: template
    });
    
    if (response && response.success) {
      alert('Template saved successfully');
      await loadTemplatesData();
    } else {
      alert('Error saving template: ' + (response ? response.error : 'Unknown error'));
    }
  } catch (error) {
    console.error('Error saving template:', error);
    alert('Error saving template. Please try again.');
  }
}

// Save settings
async function saveSettings() {
  try {
    const settings = {
      automation: {
        confirmBeforeSend: elements.confirmBeforeSend.checked,
        enableQueueProcessing: elements.enableQueueProcessing.checked
      },
      rateLimit: {
        messagesPerHour: parseInt(elements.messagesPerHour.value, 10),
        messagesPerDay: parseInt(elements.messagesPerDay.value, 10)
      }
    };
    
    const response = await chrome.runtime.sendMessage({
      action: 'updateSettings',
      data: settings
    });
    
    if (response && response.success) {
      alert('Settings saved successfully');
    } else {
      alert('Error saving settings: ' + (response ? response.error : 'Unknown error'));
    }
  } catch (error) {
    console.error('Error saving settings:', error);
    alert('Error saving settings. Please try again.');
  }
}

// Reset settings
async function resetSettings() {
  try {
    if (!confirm('Reset all settings to default values?')) {
      return;
    }
    
    const response = await chrome.runtime.sendMessage({
      action: 'resetSettings'
    });
    
    if (response && response.success) {
      alert('Settings reset successfully');
      await loadSettingsData();
    } else {
      alert('Error resetting settings: ' + (response ? response.error : 'Unknown error'));
    }
  } catch (error) {
    console.error('Error resetting settings:', error);
    alert('Error resetting settings. Please try again.');
  }
}
