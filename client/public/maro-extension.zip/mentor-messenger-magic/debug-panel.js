// debug-panel.js - UI controller for the debugging panel
import debug from './debug.js';

// DOM elements
const elements = {
  // Tabs
  tabs: document.querySelectorAll('.debug-tab'),
  panels: document.querySelectorAll('.debug-panel'),
  
  // Controls
  enableDebug: document.getElementById('enable-debug'),
  exportDebug: document.getElementById('export-debug'),
  importDebug: document.getElementById('import-debug'),
  clearDebug: document.getElementById('clear-debug'),
  
  // Logs panel
  logLevel: document.getElementById('log-level'),
  logComponent: document.getElementById('log-component'),
  logSearch: document.getElementById('log-search'),
  logLimit: document.getElementById('log-limit'),
  refreshLogs: document.getElementById('refresh-logs'),
  logsBody: document.getElementById('logs-body'),
  
  // State panel
  stateComponent: document.getElementById('state-component'),
  stateSearch: document.getElementById('state-search'),
  refreshState: document.getElementById('refresh-state'),
  stateContainer: document.getElementById('state-container'),
  
  // Network panel
  networkUrl: document.getElementById('network-url'),
  networkMethod: document.getElementById('network-method'),
  networkStatus: document.getElementById('network-status'),
  networkLimit: document.getElementById('network-limit'),
  refreshNetwork: document.getElementById('refresh-network'),
  networkContainer: document.getElementById('network-container'),
  
  // Performance panel
  refreshPerformance: document.getElementById('refresh-performance'),
  performanceContainer: document.getElementById('performance-container'),
  
  // Settings panel
  settingEnabled: document.getElementById('setting-enabled'),
  settingPersistence: document.getElementById('setting-persistence'),
  settingLogLevel: document.getElementById('setting-log-level'),
  settingMaxLogs: document.getElementById('setting-max-logs'),
  saveSettings: document.getElementById('save-settings'),
  
  // Modals
  contextModal: document.getElementById('context-modal'),
  contextContent: document.getElementById('context-content'),
  closeModal: document.getElementById('close-modal'),
  importModal: document.getElementById('import-modal'),
  importData: document.getElementById('import-data'),
  confirmImport: document.getElementById('confirm-import'),
  cancelImport: document.getElementById('cancel-import'),
  
  // Notification
  notification: document.getElementById('notification')
};

// Initialize the debug panel
async function initialize() {
  console.log('Initializing debug panel');
  
  // Set up tab switching
  setupTabs();
  
  // Set up event listeners
  setupEventListeners();
  
  // Load initial data
  await loadInitialData();
}

// Set up tab switching
function setupTabs() {
  elements.tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      // Remove active class from all tabs and panels
      elements.tabs.forEach(t => t.classList.remove('active'));
      elements.panels.forEach(p => p.classList.remove('active'));
      
      // Add active class to clicked tab and corresponding panel
      tab.classList.add('active');
      const panelId = `${tab.dataset.tab}-panel`;
      document.getElementById(panelId).classList.add('active');
      
      // Load data for the selected tab
      loadTabData(tab.dataset.tab);
    });
  });
}

// Set up event listeners
function setupEventListeners() {
  // Debug controls
  elements.enableDebug.addEventListener('click', toggleDebug);
  elements.exportDebug.addEventListener('click', exportDebugData);
  elements.importDebug.addEventListener('click', showImportModal);
  elements.clearDebug.addEventListener('click', clearDebugData);
  
  // Logs panel
  elements.refreshLogs.addEventListener('click', () => loadLogs());
  elements.logLevel.addEventListener('change', () => loadLogs());
  elements.logComponent.addEventListener('change', () => loadLogs());
  elements.logSearch.addEventListener('input', debounce(() => loadLogs(), 300));
  elements.logLimit.addEventListener('change', () => loadLogs());
  
  // State panel
  elements.refreshState.addEventListener('click', () => loadState());
  elements.stateComponent.addEventListener('change', () => loadState());
  elements.stateSearch.addEventListener('input', debounce(() => loadState(), 300));
  
  // Network panel
  elements.refreshNetwork.addEventListener('click', () => loadNetwork());
  elements.networkUrl.addEventListener('input', debounce(() => loadNetwork(), 300));
  elements.networkMethod.addEventListener('change', () => loadNetwork());
  elements.networkStatus.addEventListener('change', () => loadNetwork());
  elements.networkLimit.addEventListener('change', () => loadNetwork());
  
  // Performance panel
  elements.refreshPerformance.addEventListener('click', () => loadPerformance());
  
  // Settings panel
  elements.saveSettings.addEventListener('click', saveSettings);
  
  // Modals
  elements.closeModal.addEventListener('click', closeModals);
  document.querySelectorAll('.modal-close').forEach(button => {
    button.addEventListener('click', closeModals);
  });
  elements.confirmImport.addEventListener('click', importDebugData);
  elements.cancelImport.addEventListener('click', closeModals);
  
  // Close modals when clicking outside
  window.addEventListener('click', (event) => {
    if (event.target === elements.contextModal) {
      closeModals();
    }
    if (event.target === elements.importModal) {
      closeModals();
    }
  });
}

// Load initial data
async function loadInitialData() {
  // Update UI based on debug status
  updateDebugStatus();
  
  // Load settings
  await loadSettings();
  
  // Load data for the active tab
  const activeTab = document.querySelector('.debug-tab.active');
  if (activeTab) {
    loadTabData(activeTab.dataset.tab);
  }
}

// Load data for the selected tab
async function loadTabData(tab) {
  switch (tab) {
    case 'logs':
      await loadLogs();
      break;
    case 'state':
      await loadState();
      break;
    case 'network':
      await loadNetwork();
      break;
    case 'performance':
      await loadPerformance();
      break;
    case 'settings':
      await loadSettings();
      break;
  }
}

// Toggle debug mode
async function toggleDebug() {
  if (debug.enabled) {
    await debug.disable();
  } else {
    await debug.enable();
  }
  
  updateDebugStatus();
  showNotification(debug.enabled ? 'Debugging enabled' : 'Debugging disabled');
}

// Update UI based on debug status
function updateDebugStatus() {
  elements.enableDebug.textContent = debug.enabled ? 'Disable Debugging' : 'Enable Debugging';
  elements.enableDebug.classList.toggle('secondary', debug.enabled);
}

// Load logs
async function loadLogs() {
  // Get filter values
  const filters = {
    level: elements.logLevel.value,
    component: elements.logComponent.value,
    search: elements.logSearch.value,
    limit: parseInt(elements.logLimit.value) || 0
  };
  
  // Get logs
  const logs = await debug.getLogs(filters);
  
  // Clear logs container
  elements.logsBody.innerHTML = '';
  
  // Check if empty
  if (logs.length === 0) {
    elements.logsBody.innerHTML = `
      <tr>
        <td colspan="5" class="empty-state">No logs found matching the current filters</td>
      </tr>
    `;
    return;
  }
  
  // Populate logs
  logs.forEach(log => {
    const row = document.createElement('tr');
    
    // Format timestamp
    const timestamp = new Date(log.timestamp);
    const timeString = timestamp.toLocaleTimeString();
    
    row.innerHTML = `
      <td>${timeString}</td>
      <td><span class="log-level ${log.level}">${log.level.toUpperCase()}</span></td>
      <td>${log.component}</td>
      <td class="log-message">${escapeHtml(log.message)}</td>
      <td><a href="#" class="log-context" data-context='${JSON.stringify(log.context)}'>View</a></td>
    `;
    
    elements.logsBody.appendChild(row);
  });
  
  // Add event listeners to context links
  document.querySelectorAll('.log-context').forEach(link => {
    link.addEventListener('click', (event) => {
      event.preventDefault();
      showContextModal(JSON.parse(link.dataset.context));
    });
  });
  
  // Update component filter options
  updateComponentOptions(logs);
}

// Update component filter options
function updateComponentOptions(logs) {
  // Get unique components
  const components = [...new Set(logs.map(log => log.component))];
  
  // Current selected value
  const currentValue = elements.logComponent.value;
  
  // Clear options except the first one
  while (elements.logComponent.options.length > 1) {
    elements.logComponent.remove(1);
  }
  
  // Add component options
  components.forEach(component => {
    const option = document.createElement('option');
    option.value = component;
    option.textContent = component;
    elements.logComponent.appendChild(option);
  });
  
  // Restore selected value if it exists
  if (components.includes(currentValue)) {
    elements.logComponent.value = currentValue;
  }
}

// Load state
async function loadState() {
  // Get component filter
  const componentFilter = elements.stateComponent.value;
  const searchFilter = elements.stateSearch.value.toLowerCase();
  
  // Get state data
  const state = await debug.getState(componentFilter);
  
  // Clear state container
  elements.stateContainer.innerHTML = '';
  
  // Check if empty
  if (Object.keys(state).length === 0) {
    elements.stateContainer.innerHTML = `
      <div class="empty-state">No state data available</div>
    `;
    return;
  }
  
  // Format and display state
  let stateHtml = '';
  
  if (componentFilter) {
    // Single component view
    for (const [stateName, stateData] of Object.entries(state)) {
      // Skip if doesn't match search
      if (searchFilter && !stateName.toLowerCase().includes(searchFilter) && 
          !JSON.stringify(stateData).toLowerCase().includes(searchFilter)) {
        continue;
      }
      
      stateHtml += `
        <div class="collapsible" data-target="state-${stateName}">
          <strong>${stateName}</strong> 
          <span class="badge">${new Date(stateData.capturedAt).toLocaleTimeString()}</span>
        </div>
        <div id="state-${stateName}" class="collapsible-content">
          ${formatJson(stateData.data)}
        </div>
      `;
    }
  } else {
    // All components view
    for (const [componentName, states] of Object.entries(state)) {
      // Skip if doesn't match search
      if (searchFilter && !componentName.toLowerCase().includes(searchFilter) && 
          !JSON.stringify(states).toLowerCase().includes(searchFilter)) {
        continue;
      }
      
      stateHtml += `
        <div class="collapsible" data-target="component-${componentName}">
          <strong>${componentName}</strong> 
          <span class="badge">${Object.keys(states).length}</span>
        </div>
        <div id="component-${componentName}" class="collapsible-content">
      `;
      
      for (const [stateName, stateData] of Object.entries(states)) {
        stateHtml += `
          <div class="collapsible" data-target="state-${componentName}-${stateName}">
            <strong>${stateName}</strong> 
            <span class="badge">${new Date(stateData.capturedAt).toLocaleTimeString()}</span>
          </div>
          <div id="state-${componentName}-${stateName}" class="collapsible-content">
            ${formatJson(stateData.data)}
          </div>
        `;
      }
      
      stateHtml += '</div>';
    }
  }
  
  // If no results after filtering
  if (!stateHtml) {
    elements.stateContainer.innerHTML = `
      <div class="empty-state">No state data matching the search criteria</div>
    `;
    return;
  }
  
  elements.stateContainer.innerHTML = stateHtml;
  
  // Update component filter options
  updateStateComponentOptions(state);
  
  // Add event listeners to collapsibles
  document.querySelectorAll('.collapsible').forEach(collapsible => {
    collapsible.addEventListener('click', () => {
      const target = document.getElementById(collapsible.dataset.target);
      target.classList.toggle('visible');
    });
  });
}

// Update state component filter options
function updateStateComponentOptions(state) {
  // Get components
  const components = Object.keys(state);
  
  // Current selected value
  const currentValue = elements.stateComponent.value;
  
  // Clear options except the first one
  while (elements.stateComponent.options.length > 1) {
    elements.stateComponent.remove(1);
  }
  
  // Add component options
  components.forEach(component => {
    const option = document.createElement('option');
    option.value = component;
    option.textContent = component;
    elements.stateComponent.appendChild(option);
  });
  
  // Restore selected value if it exists
  if (components.includes(currentValue)) {
    elements.stateComponent.value = currentValue;
  }
}

// Load network logs
async function loadNetwork() {
  // Get filter values
  const filters = {
    url: elements.networkUrl.value,
    method: elements.networkMethod.value,
    status: elements.networkStatus.value,
    limit: parseInt(elements.networkLimit.value) || 0
  };
  
  // Get network logs
  const networkLogs = await debug.getNetworkLogs(filters);
  
  // Clear network container
  elements.networkContainer.innerHTML = '';
  
  // Check if empty
  if (networkLogs.length === 0) {
    elements.networkContainer.innerHTML = `
      <div class="empty-state">No network requests found matching the current filters</div>
    `;
    return;
  }
  
  // Populate network logs
  networkLogs.forEach(log => {
    const isError = log.responseStatus >= 400;
    const statusClass = isError ? 'error' : 'success';
    
    const networkItem = document.createElement('div');
    networkItem.className = `network-item ${isError ? 'error' : ''}`;
    
    networkItem.innerHTML = `
      <div class="network-item-header">
        <span class="network-item-url">${truncateText(log.url, 50)}</span>
        <div>
          <span class="network-item-method">${log.method}</span>
          ${log.responseStatus ? `<span class="network-item-status ${statusClass}">${log.responseStatus}</span>` : ''}
        </div>
      </div>
      <div class="network-item-details">
        ${log.duration ? `${log.duration}ms · ` : ''}${new Date(log.timestamp).toLocaleTimeString()}
      </div>
      <div class="collapsible" data-target="network-request-${log.timestamp.replace(/[^a-zA-Z0-9]/g, '')}">
        Request Data
      </div>
      <div id="network-request-${log.timestamp.replace(/[^a-zA-Z0-9]/g, '')}" class="collapsible-content">
        ${formatJson(log.requestData)}
      </div>
      ${log.responseData ? `
        <div class="collapsible" data-target="network-response-${log.timestamp.replace(/[^a-zA-Z0-9]/g, '')}">
          Response Data
        </div>
        <div id="network-response-${log.timestamp.replace(/[^a-zA-Z0-9]/g, '')}" class="collapsible-content">
          ${formatJson(log.responseData)}
        </div>
      ` : ''}
    `;
    
    elements.networkContainer.appendChild(networkItem);
  });
  
  // Add event listeners to collapsibles
  document.querySelectorAll('.collapsible').forEach(collapsible => {
    collapsible.addEventListener('click', () => {
      const target = document.getElementById(collapsible.dataset.target);
      target.classList.toggle('visible');
    });
  });
}

// Load performance data
async function loadPerformance() {
  // Get performance data
  const performanceData = await debug.getPerformanceData();
  
  // Clear performance container
  elements.performanceContainer.innerHTML = '';
  
  // Check if empty
  if (!performanceData.operations || Object.keys(performanceData.operations).length === 0) {
    elements.performanceContainer.innerHTML = `
      <div class="empty-state">No performance data available</div>
    `;
    return;
  }
  
  // Find max duration for scaling
  let maxDuration = 0;
  Object.values(performanceData.operations).forEach(operation => {
    if (operation.maxDuration > maxDuration) {
      maxDuration = operation.maxDuration;
    }
  });
  
  // Populate performance data
  for (const [operationName, data] of Object.entries(performanceData.operations)) {
    const percentOfMax = (data.averageDuration / maxDuration) * 100;
    
    const operationItem = document.createElement('div');
    operationItem.className = 'card';
    
    operationItem.innerHTML = `
      <div class="card-title">${operationName}</div>
      <div>
        <div>Average: ${data.averageDuration.toFixed(2)}ms (${data.count} calls)</div>
        <div>Min: ${data.minDuration.toFixed(2)}ms / Max: ${data.maxDuration.toFixed(2)}ms</div>
        <div class="performance-bar">
          <div class="performance-progress" style="width: ${percentOfMax}%"></div>
          <div class="performance-label">${data.averageDuration.toFixed(2)}ms</div>
        </div>
      </div>
    `;
    
    elements.performanceContainer.appendChild(operationItem);
  }
}

// Load settings
async function loadSettings() {
  // Get debug data
  const data = await chrome.storage.local.get('debugData');
  if (!data.debugData || !data.debugData.settings) {
    return;
  }
  
  const settings = data.debugData.settings;
  
  // Update settings form
  elements.settingEnabled.checked = settings.enabled;
  elements.settingPersistence.checked = settings.persistence;
  elements.settingLogLevel.value = settings.logLevel;
  elements.settingMaxLogs.value = settings.maxLogs;
}

// Save settings
async function saveSettings() {
  const settings = {
    enabled: elements.settingEnabled.checked,
    persistence: elements.settingPersistence.checked,
    logLevel: elements.settingLogLevel.value,
    maxLogs: parseInt(elements.settingMaxLogs.value)
  };
  
  // Update settings
  const success = await debug.updateSettings(settings);
  
  if (success) {
    showNotification('Settings saved successfully');
    updateDebugStatus();
  } else {
    showNotification('Failed to save settings', 'error');
  }
}

// Export debug data
async function exportDebugData() {
  try {
    const jsonData = await debug.exportData();
    
    // Create download link
    const blob = new Blob([jsonData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `debug-data-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    showNotification('Debug data exported successfully');
  } catch (error) {
    console.error('Error exporting debug data:', error);
    showNotification('Failed to export debug data', 'error');
  }
}

// Show import modal
function showImportModal() {
  elements.importData.value = '';
  elements.importModal.classList.add('visible');
}

// Import debug data
async function importDebugData() {
  try {
    const jsonData = elements.importData.value;
    if (!jsonData) {
      showNotification('No data to import', 'warning');
      return;
    }
    
    const success = await debug.importData(jsonData);
    
    if (success) {
      closeModals();
      showNotification('Debug data imported successfully');
      
      // Reload current tab data
      const activeTab = document.querySelector('.debug-tab.active');
      if (activeTab) {
        loadTabData(activeTab.dataset.tab);
      }
    } else {
      showNotification('Failed to import debug data', 'error');
    }
  } catch (error) {
    console.error('Error importing debug data:', error);
    showNotification('Invalid JSON data', 'error');
  }
}

// Clear debug data
async function clearDebugData() {
  if (confirm('Are you sure you want to clear all debug data? This cannot be undone.')) {
    const success = await debug.clearData();
    
    if (success) {
      showNotification('Debug data cleared successfully');
      
      // Reload current tab data
      const activeTab = document.querySelector('.debug-tab.active');
      if (activeTab) {
        loadTabData(activeTab.dataset.tab);
      }
    } else {
      showNotification('Failed to clear debug data', 'error');
    }
  }
}

// Show context modal
function showContextModal(context) {
  elements.contextContent.innerHTML = formatJson(context);
  elements.contextModal.classList.add('visible');
}

// Close all modals
function closeModals() {
  elements.contextModal.classList.remove('visible');
  elements.importModal.classList.remove('visible');
}

// Show notification
function showNotification(message, type = 'success') {
  elements.notification.textContent = message;
  elements.notification.className = `notification ${type}`;
  elements.notification.classList.add('visible');
  
  // Hide after 3 seconds
  setTimeout(() => {
    elements.notification.classList.remove('visible');
  }, 3000);
}

// Format JSON for display
function formatJson(data) {
  if (!data) return '<span class="json-null">null</span>';
  
  try {
    // Convert to string if not already
    const jsonString = typeof data === 'string' ? data : JSON.stringify(data, null, 2);
    
    // Syntax highlighting
    return jsonString
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, (match) => {
        let cls = 'json-number';
        if (/^"/.test(match)) {
          if (/:$/.test(match)) {
            cls = 'json-key';
            match = match.replace(/"/g, '').replace(/:$/, '');
            return `"<span class="${cls}">${match}</span>":`;
          } else {
            cls = 'json-string';
          }
        } else if (/true|false/.test(match)) {
          cls = 'json-boolean';
        } else if (/null/.test(match)) {
          cls = 'json-null';
        }
        return `<span class="${cls}">${match}</span>`;
      })
      .replace(/\n/g, '<br>')
      .replace(/\s{2}/g, '&nbsp;&nbsp;');
  } catch (e) {
    return `<span class="json-string">${escapeHtml(String(data))}</span>`;
  }
}

// Escape HTML
function escapeHtml(text) {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// Truncate text with ellipsis
function truncateText(text, maxLength) {
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength) + '...';
}

// Debounce function
function debounce(func, wait) {
  let timeout;
  return function(...args) {
    clearTimeout(timeout);
    timeout = setTimeout(() => func.apply(this, args), wait);
  };
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', initialize);
