/**
 * Template Management Module
 * Handles message templates with variables, categories, and analytics
 */

class TemplateManager {
  constructor() {
    this.templates = [];
    this.categories = [];
    this.analytics = {};
  }

  /**
   * Initialize template manager
   */
  async initialize() {
    const stored = await chrome.storage.local.get(['templates', 'templateCategories', 'templateAnalytics']);
    
    if (stored.templates) {
      this.templates = stored.templates;
    }
    
    if (stored.templateCategories) {
      this.categories = stored.templateCategories;
    } else {
      // Initialize default categories
      this.categories = [
        { id: 'intro', name: 'Introduction', color: '#3b82f6' },
        { id: 'followup', name: 'Follow-up', color: '#10b981' },
        { id: 'networking', name: 'Networking', color: '#8b5cf6' },
        { id: 'custom', name: 'Custom', color: '#f59e0b' }
      ];
      await this.saveCategories();
    }
    
    if (stored.templateAnalytics) {
      this.analytics = stored.templateAnalytics;
    }
  }

  /**
   * Create a new template
   */
  async createTemplate(templateData) {
    const template = {
      id: this.generateId(),
      name: templateData.name,
      subject: templateData.subject || '',
      content: templateData.content,
      category: templateData.category || 'custom',
      tags: templateData.tags || [],
      variables: this.extractVariables(templateData.content),
      version: 1,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      usage: {
        count: 0,
        lastUsed: null,
        successRate: 0,
        responseRate: 0
      }
    };

    this.templates.push(template);
    await this.saveTemplates();
    
    return template;
  }

  /**
   * Update an existing template
   */
  async updateTemplate(id, updates) {
    const template = this.templates.find(t => t.id === id);
    
    if (!template) {
      throw new Error('Template not found');
    }

    // Create new version if content changed
    if (updates.content && updates.content !== template.content) {
      template.version++;
    }

    Object.assign(template, updates);
    template.updatedAt = Date.now();
    
    if (updates.content) {
      template.variables = this.extractVariables(updates.content);
    }

    await this.saveTemplates();
    return template;
  }

  /**
   * Delete a template
   */
  async deleteTemplate(id) {
    const index = this.templates.findIndex(t => t.id === id);
    
    if (index === -1) {
      throw new Error('Template not found');
    }

    this.templates.splice(index, 1);
    await this.saveTemplates();
  }

  /**
   * Get template by ID
   */
  getTemplate(id) {
    return this.templates.find(t => t.id === id);
  }

  /**
   * Get all templates
   */
  getAllTemplates() {
    return this.templates;
  }

  /**
   * Get templates by category
   */
  getTemplatesByCategory(category) {
    return this.templates.filter(t => t.category === category);
  }

  /**
   * Search templates
   */
  searchTemplates(query) {
    const lowerQuery = query.toLowerCase();
    return this.templates.filter(t => 
      t.name.toLowerCase().includes(lowerQuery) ||
      t.content.toLowerCase().includes(lowerQuery) ||
      t.tags.some(tag => tag.toLowerCase().includes(lowerQuery))
    );
  }

  /**
   * Extract variables from template content
   */
  extractVariables(content) {
    const regex = /{{(\w+)}}/g;
    const variables = [];
    let match;

    while ((match = regex.exec(content)) !== null) {
      if (!variables.includes(match[1])) {
        variables.push(match[1]);
      }
    }

    return variables;
  }

  /**
   * Process template with variables
   */
  processTemplate(templateId, variables) {
    const template = this.getTemplate(templateId);
    
    if (!template) {
      throw new Error('Template not found');
    }

    let content = template.content;
    let subject = template.subject;

    // Replace variables in content
    Object.keys(variables).forEach(key => {
      const regex = new RegExp(`{{${key}}}`, 'g');
      content = content.replace(regex, variables[key]);
      subject = subject.replace(regex, variables[key]);
    });

    return {
      subject,
      content,
      templateId: template.id,
      templateName: template.name
    };
  }

  /**
   * Record template usage
   */
  async recordUsage(templateId, success = true) {
    const template = this.getTemplate(templateId);
    
    if (!template) {
      return;
    }

    template.usage.count++;
    template.usage.lastUsed = Date.now();

    // Update analytics
    if (!this.analytics[templateId]) {
      this.analytics[templateId] = {
        uses: [],
        responses: [],
        conversions: []
      };
    }

    this.analytics[templateId].uses.push({
      timestamp: Date.now(),
      success
    });

    await this.saveTemplates();
    await this.saveAnalytics();
  }

  /**
   * Record template response
   */
  async recordResponse(templateId, responseTime) {
    if (!this.analytics[templateId]) {
      this.analytics[templateId] = {
        uses: [],
        responses: [],
        conversions: []
      };
    }

    this.analytics[templateId].responses.push({
      timestamp: Date.now(),
      responseTime
    });

    // Update response rate
    const template = this.getTemplate(templateId);
    if (template) {
      const totalUses = this.analytics[templateId].uses.length;
      const totalResponses = this.analytics[templateId].responses.length;
      template.usage.responseRate = totalResponses / totalUses;
      await this.saveTemplates();
    }

    await this.saveAnalytics();
  }

  /**
   * Get template analytics
   */
  getTemplateAnalytics(templateId) {
    const template = this.getTemplate(templateId);
    const analytics = this.analytics[templateId] || { uses: [], responses: [], conversions: [] };

    if (!template) {
      return null;
    }

    const totalUses = analytics.uses.length;
    const successfulUses = analytics.uses.filter(u => u.success).length;
    const totalResponses = analytics.responses.length;
    const avgResponseTime = analytics.responses.length > 0
      ? analytics.responses.reduce((sum, r) => sum + r.responseTime, 0) / analytics.responses.length
      : 0;

    return {
      template: {
        id: template.id,
        name: template.name,
        category: template.category,
        version: template.version
      },
      usage: {
        totalUses,
        successfulUses,
        successRate: totalUses > 0 ? successfulUses / totalUses : 0,
        lastUsed: template.usage.lastUsed
      },
      engagement: {
        totalResponses,
        responseRate: totalUses > 0 ? totalResponses / totalUses : 0,
        avgResponseTime: avgResponseTime / (1000 * 60 * 60) // Convert to hours
      }
    };
  }

  /**
   * Get top performing templates
   */
  getTopTemplates(limit = 5) {
    return this.templates
      .filter(t => t.usage.count > 0)
      .sort((a, b) => {
        // Sort by combination of usage count and response rate
        const scoreA = a.usage.count * (a.usage.responseRate || 0.5);
        const scoreB = b.usage.count * (b.usage.responseRate || 0.5);
        return scoreB - scoreA;
      })
      .slice(0, limit)
      .map(t => ({
        id: t.id,
        name: t.name,
        category: t.category,
        usageCount: t.usage.count,
        responseRate: t.usage.responseRate
      }));
  }

  /**
   * Suggest templates based on context
   */
  suggestTemplates(context) {
    // Context can include: recipientProfile, previousMessages, etc.
    const suggestions = [];

    // Simple suggestion logic - can be enhanced with ML
    if (context.isFirstContact) {
      suggestions.push(...this.getTemplatesByCategory('intro'));
    } else {
      suggestions.push(...this.getTemplatesByCategory('followup'));
    }

    // Add top performing templates
    const topTemplates = this.getTopTemplates(3);
    topTemplates.forEach(top => {
      const template = this.getTemplate(top.id);
      if (template && !suggestions.find(s => s.id === template.id)) {
        suggestions.push(template);
      }
    });

    return suggestions.slice(0, 5);
  }

  /**
   * Create category
   */
  async createCategory(name, color) {
    const category = {
      id: name.toLowerCase().replace(/\s+/g, '_'),
      name,
      color
    };

    this.categories.push(category);
    await this.saveCategories();
    
    return category;
  }

  /**
   * Get all categories
   */
  getCategories() {
    return this.categories;
  }

  /**
   * Save templates to storage
   */
  async saveTemplates() {
    await chrome.storage.local.set({ templates: this.templates });
  }

  /**
   * Save categories to storage
   */
  async saveCategories() {
    await chrome.storage.local.set({ templateCategories: this.categories });
  }

  /**
   * Save analytics to storage
   */
  async saveAnalytics() {
    await chrome.storage.local.set({ templateAnalytics: this.analytics });
  }

  /**
   * Generate unique ID
   */
  generateId() {
    return `tpl_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Export templates
   */
  exportTemplates() {
    return {
      templates: this.templates,
      categories: this.categories,
      exportedAt: Date.now(),
      version: '1.0'
    };
  }

  /**
   * Import templates
   */
  async importTemplates(data) {
    if (!data.templates || !Array.isArray(data.templates)) {
      throw new Error('Invalid import data');
    }

    // Merge with existing templates
    data.templates.forEach(importedTemplate => {
      const existing = this.templates.find(t => t.id === importedTemplate.id);
      if (!existing) {
        this.templates.push(importedTemplate);
      }
    });

    // Merge categories
    if (data.categories) {
      data.categories.forEach(importedCategory => {
        const existing = this.categories.find(c => c.id === importedCategory.id);
        if (!existing) {
          this.categories.push(importedCategory);
        }
      });
    }

    await this.saveTemplates();
    await this.saveCategories();
  }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = TemplateManager;
}
