/**
 * Message Sender Module
 * Handles automated message sending on MicroMentor platform
 */

class MessageSender {
  constructor() {
    this.queue = [];
    this.isProcessing = false;
    this.rateLimits = {
      messagesPerHour: 20,
      messagesPerDay: 100,
      minDelayBetweenMessages: 30000, // 30 seconds
      maxDelayBetweenMessages: 120000 // 2 minutes
    };
    this.stats = {
      sent: 0,
      failed: 0,
      pending: 0,
      lastSentTime: null
    };
  }

  /**
   * Initialize the message sender
   */
  async initialize() {
    // Load queue from storage
    const stored = await chrome.storage.local.get(['messageQueue', 'messageStats']);
    if (stored.messageQueue) {
      this.queue = stored.messageQueue;
    }
    if (stored.messageStats) {
      this.stats = stored.messageStats;
    }
    
    // Start processing if there are queued messages
    if (this.queue.length > 0 && !this.isProcessing) {
      this.startProcessing();
    }
  }

  /**
   * Add a message to the sending queue
   */
  async addToQueue(message) {
    const queueItem = {
      id: this.generateId(),
      recipientId: message.recipientId,
      recipientName: message.recipientName,
      subject: message.subject,
      content: message.content,
      template: message.template,
      variables: message.variables,
      status: 'pending',
      attempts: 0,
      maxAttempts: 3,
      createdAt: Date.now(),
      scheduledFor: message.scheduledFor || Date.now()
    };

    this.queue.push(queueItem);
    this.stats.pending = this.queue.filter(m => m.status === 'pending').length;
    
    await this.saveQueue();
    
    // Start processing if not already running
    if (!this.isProcessing) {
      this.startProcessing();
    }

    return queueItem.id;
  }

  /**
   * Start processing the message queue
   */
  async startProcessing() {
    if (this.isProcessing) {
      return;
    }

    this.isProcessing = true;

    while (this.queue.length > 0) {
      // Check rate limits
      if (!this.canSendMessage()) {
        const waitTime = this.getWaitTime();
        await this.delay(waitTime);
        continue;
      }

      // Get next pending message
      const message = this.queue.find(m => 
        m.status === 'pending' && 
        m.scheduledFor <= Date.now()
      );

      if (!message) {
        // No messages ready to send
        break;
      }

      try {
        await this.sendMessage(message);
        message.status = 'sent';
        message.sentAt = Date.now();
        this.stats.sent++;
        this.stats.lastSentTime = Date.now();
      } catch (error) {
        message.attempts++;
        if (message.attempts >= message.maxAttempts) {
          message.status = 'failed';
          message.error = error.message;
          this.stats.failed++;
        } else {
          // Retry with exponential backoff
          message.scheduledFor = Date.now() + (Math.pow(2, message.attempts) * 60000);
        }
      }

      // Remove completed messages from queue
      this.queue = this.queue.filter(m => 
        m.status !== 'sent' && m.status !== 'failed'
      );
      
      this.stats.pending = this.queue.length;
      await this.saveQueue();

      // Add random delay between messages
      const delay = this.getRandomDelay();
      await this.delay(delay);
    }

    this.isProcessing = false;
  }

  /**
   * Send a single message
   */
  async sendMessage(message) {
    // Inject content script if needed
    const tabs = await chrome.tabs.query({ url: '*://micromentor.org/*' });
    
    if (tabs.length === 0) {
      throw new Error('No MicroMentor tab found. Please open MicroMentor in a tab.');
    }

    const tab = tabs[0];

    // Process template variables
    let content = message.content;
    if (message.variables) {
      Object.keys(message.variables).forEach(key => {
        const regex = new RegExp(`{{${key}}}`, 'g');
        content = content.replace(regex, message.variables[key]);
      });
    }

    // Send message via content script
    const response = await chrome.tabs.sendMessage(tab.id, {
      action: 'sendMessage',
      data: {
        recipientId: message.recipientId,
        recipientName: message.recipientName,
        subject: message.subject,
        content: content
      }
    });

    if (!response || !response.success) {
      throw new Error(response?.error || 'Failed to send message');
    }

    return response;
  }

  /**
   * Check if we can send a message based on rate limits
   */
  canSendMessage() {
    const now = Date.now();
    const oneHourAgo = now - (60 * 60 * 1000);
    const oneDayAgo = now - (24 * 60 * 60 * 1000);

    // Check minimum delay since last message
    if (this.stats.lastSentTime && 
        (now - this.stats.lastSentTime) < this.rateLimits.minDelayBetweenMessages) {
      return false;
    }

    // Check hourly limit
    const sentLastHour = this.getSentCount(oneHourAgo);
    if (sentLastHour >= this.rateLimits.messagesPerHour) {
      return false;
    }

    // Check daily limit
    const sentLastDay = this.getSentCount(oneDayAgo);
    if (sentLastDay >= this.rateLimits.messagesPerDay) {
      return false;
    }

    return true;
  }

  /**
   * Get wait time until next message can be sent
   */
  getWaitTime() {
    const now = Date.now();
    
    // Check minimum delay
    if (this.stats.lastSentTime) {
      const timeSinceLastMessage = now - this.stats.lastSentTime;
      if (timeSinceLastMessage < this.rateLimits.minDelayBetweenMessages) {
        return this.rateLimits.minDelayBetweenMessages - timeSinceLastMessage;
      }
    }

    // Default wait time
    return this.rateLimits.minDelayBetweenMessages;
  }

  /**
   * Get random delay between min and max
   */
  getRandomDelay() {
    const min = this.rateLimits.minDelayBetweenMessages;
    const max = this.rateLimits.maxDelayBetweenMessages;
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  /**
   * Get count of sent messages since a given time
   */
  getSentCount(since) {
    // This would need to query from storage in a real implementation
    // For now, returning 0 as placeholder
    return 0;
  }

  /**
   * Save queue to storage
   */
  async saveQueue() {
    await chrome.storage.local.set({
      messageQueue: this.queue,
      messageStats: this.stats
    });
  }

  /**
   * Get queue status
   */
  getStatus() {
    return {
      isProcessing: this.isProcessing,
      queueLength: this.queue.length,
      stats: this.stats,
      rateLimits: this.rateLimits
    };
  }

  /**
   * Clear the queue
   */
  async clearQueue() {
    this.queue = [];
    this.stats.pending = 0;
    await this.saveQueue();
  }

  /**
   * Pause processing
   */
  pause() {
    this.isProcessing = false;
  }

  /**
   * Resume processing
   */
  resume() {
    if (this.queue.length > 0) {
      this.startProcessing();
    }
  }

  /**
   * Utility: Generate unique ID
   */
  generateId() {
    return `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Utility: Delay helper
   */
  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = MessageSender;
}
