/**
 * Background Worker for CPU-intensive tasks
 */

// Compression utilities
const compress = async (data) => {
  const json = JSON.stringify(data);
  const encoder = new TextEncoder();
  const uint8Array = encoder.encode(json);
  
  const stream = new ReadableStream({
    start(controller) {
      controller.enqueue(uint8Array);
      controller.close();
    }
  });

  const compressedStream = stream.pipeThrough(new CompressionStream('gzip'));
  const chunks = [];
  
  for await (const chunk of compressedStream) {
    chunks.push(chunk);
  }

  const compressed = new Uint8Array(
    chunks.reduce((acc, chunk) => acc + chunk.length, 0)
  );
  
  let offset = 0;
  for (const chunk of chunks) {
    compressed.set(chunk, offset);
    offset += chunk.length;
  }

  return Array.from(compressed);
};

const decompress = async (compressedArray) => {
  const uint8Array = new Uint8Array(compressedArray);
  
  const stream = new ReadableStream({
    start(controller) {
      controller.enqueue(uint8Array);
      controller.close();
    }
  });

  const decompressedStream = stream.pipeThrough(new DecompressionStream('gzip'));
  const chunks = [];
  
  for await (const chunk of decompressedStream) {
    chunks.push(chunk);
  }

  const decompressed = new Uint8Array(
    chunks.reduce((acc, chunk) => acc + chunk.length, 0)
  );
  
  let offset = 0;
  for (const chunk of chunks) {
    decompressed.set(chunk, offset);
    offset += chunk.length;
  }

  const decoder = new TextDecoder();
  const json = decoder.decode(decompressed);
  return JSON.parse(json);
};

// Analytics processing
const processAnalytics = (data) => {
  const { messages, period } = data;
  const now = Date.now();
  const periodMs = period * 24 * 60 * 60 * 1000;
  
  const filtered = messages.filter(m => now - m.timestamp < periodMs);
  
  const stats = {
    total: filtered.length,
    sent: filtered.filter(m => m.status === 'sent').length,
    failed: filtered.filter(m => m.status === 'failed').length,
    responseRate: 0, // Calculated if response data available
    byDay: {}
  };
  
  // Group by day
  filtered.forEach(m => {
    const date = new Date(m.timestamp).toISOString().split('T')[0];
    if (!stats.byDay[date]) {
      stats.byDay[date] = { sent: 0, failed: 0 };
    }
    if (m.status === 'sent') stats.byDay[date].sent++;
    if (m.status === 'failed') stats.byDay[date].failed++;
  });
  
  return stats;
};

// Message handlers
self.onmessage = async (e) => {
  const { id, method, args } = e.data;
  
  try {
    let result;
    
    switch (method) {
      case 'compress':
        result = await compress(args[0]);
        break;
      case 'decompress':
        result = await decompress(args[0]);
        break;
      case 'processAnalytics':
        result = processAnalytics(args[0]);
        break;
      default:
        throw new Error(`Unknown method: ${method}`);
    }
    
    self.postMessage({ id, result });
  } catch (error) {
    self.postMessage({ id, error: error.message });
  }
};
