/**
 * Analytics Module
 * Tracks and analyzes extension usage, message effectiveness, and user engagement
 */

class Analytics {
  constructor() {
    this.events = [];
    this.metrics = {
      messages: {
        sent: 0,
        failed: 0,
        pending: 0,
        scheduled: 0
      },
      responses: {
        received: 0,
        responseRate: 0,
        avgResponseTime: 0
      },
      engagement: {
        profileViews: 0,
        conversationsStarted: 0,
        conversationsActive: 0
      },
      timeSaved: {
        totalMinutes: 0,
        manualTimeEstimate: 0,
        automationTimeActual: 0
      },
      roi: {
        hoursSaved: 0,
        costPerMessage: 0,
        totalCost: 0
      }
    };
  }

  /**
   * Initialize analytics
   */
  async initialize() {
    const stored = await chrome.storage.local.get(['analyticsEvents', 'analyticsMetrics']);
    
    if (stored.analyticsEvents) {
      this.events = stored.analyticsEvents;
    }
    
    if (stored.analyticsMetrics) {
      this.metrics = stored.analyticsMetrics;
    }
  }

  /**
   * Track an event
   */
  async trackEvent(category, action, label = null, value = null) {
    const event = {
      id: this.generateId(),
      category,
      action,
      label,
      value,
      timestamp: Date.now()
    };

    this.events.push(event);

    // Keep only last 1000 events
    if (this.events.length > 1000) {
      this.events = this.events.slice(-1000);
    }

    await this.saveEvents();
    
    // Update relevant metrics
    await this.updateMetrics(event);
  }

  /**
   * Update metrics based on event
   */
  async updateMetrics(event) {
    switch (event.category) {
      case 'message':
        if (event.action === 'sent') {
          this.metrics.messages.sent++;
          // Estimate 5 minutes saved per automated message
          this.metrics.timeSaved.totalMinutes += 5;
        } else if (event.action === 'failed') {
          this.metrics.messages.failed++;
        } else if (event.action === 'scheduled') {
          this.metrics.messages.scheduled++;
        }
        break;

      case 'response':
        if (event.action === 'received') {
          this.metrics.responses.received++;
          if (event.value) {
            // Update average response time
            const currentAvg = this.metrics.responses.avgResponseTime;
            const count = this.metrics.responses.received;
            this.metrics.responses.avgResponseTime = 
              (currentAvg * (count - 1) + event.value) / count;
          }
        }
        break;

      case 'engagement':
        if (event.action === 'profile_view') {
          this.metrics.engagement.profileViews++;
        } else if (event.action === 'conversation_started') {
          this.metrics.engagement.conversationsStarted++;
          this.metrics.engagement.conversationsActive++;
        } else if (event.action === 'conversation_ended') {
          this.metrics.engagement.conversationsActive--;
        }
        break;
    }

    // Calculate derived metrics
    if (this.metrics.messages.sent > 0) {
      this.metrics.responses.responseRate = 
        this.metrics.responses.received / this.metrics.messages.sent;
    }

    this.metrics.timeSaved.hoursSaved = this.metrics.timeSaved.totalMinutes / 60;
    
    await this.saveMetrics();
  }

  /**
   * Get dashboard data
   */
  getDashboardData() {
    const now = Date.now();
    const last24Hours = now - (24 * 60 * 60 * 1000);
    const last7Days = now - (7 * 24 * 60 * 60 * 1000);
    const last30Days = now - (30 * 24 * 60 * 60 * 1000);

    return {
      overview: {
        messagesSent: this.metrics.messages.sent,
        responsesReceived: this.metrics.responses.received,
        responseRate: (this.metrics.responses.responseRate * 100).toFixed(1) + '%',
        avgResponseTime: this.formatResponseTime(this.metrics.responses.avgResponseTime),
        timeSaved: this.formatTimeSaved(this.metrics.timeSaved.hoursSaved)
      },
      activity: {
        last24Hours: this.getActivityForPeriod(last24Hours),
        last7Days: this.getActivityForPeriod(last7Days),
        last30Days: this.getActivityForPeriod(last30Days)
      },
      engagement: {
        profileViews: this.metrics.engagement.profileViews,
        conversationsStarted: this.metrics.engagement.conversationsStarted,
        conversationsActive: this.metrics.engagement.conversationsActive
      },
      roi: {
        hoursSaved: this.metrics.timeSaved.hoursSaved.toFixed(1),
        estimatedValue: this.calculateROI(),
        costPerMessage: this.metrics.roi.costPerMessage.toFixed(4),
        totalCost: this.metrics.roi.totalCost.toFixed(2)
      }
    };
  }

  /**
   * Get activity for a specific period
   */
  getActivityForPeriod(since) {
    const periodEvents = this.events.filter(e => e.timestamp >= since);
    
    const messagesSent = periodEvents.filter(e => 
      e.category === 'message' && e.action === 'sent'
    ).length;
    
    const responsesReceived = periodEvents.filter(e => 
      e.category === 'response' && e.action === 'received'
    ).length;

    return {
      messagesSent,
      responsesReceived,
      responseRate: messagesSent > 0 
        ? (responsesReceived / messagesSent * 100).toFixed(1) + '%'
        : '0%'
    };
  }

  /**
   * Get message effectiveness over time
   */
  getMessageEffectiveness(days = 30) {
    const now = Date.now();
    const period = days * 24 * 60 * 60 * 1000;
    const startTime = now - period;

    const dailyData = [];
    
    for (let i = 0; i < days; i++) {
      const dayStart = startTime + (i * 24 * 60 * 60 * 1000);
      const dayEnd = dayStart + (24 * 60 * 60 * 1000);

      const dayEvents = this.events.filter(e => 
        e.timestamp >= dayStart && e.timestamp < dayEnd
      );

      const sent = dayEvents.filter(e => 
        e.category === 'message' && e.action === 'sent'
      ).length;

      const responses = dayEvents.filter(e => 
        e.category === 'response' && e.action === 'received'
      ).length;

      dailyData.push({
        date: new Date(dayStart).toISOString().split('T')[0],
        sent,
        responses,
        responseRate: sent > 0 ? (responses / sent * 100).toFixed(1) : 0
      });
    }

    return dailyData;
  }

  /**
   * Get response rate analytics
   */
  getResponseRateAnalytics() {
    const messageEvents = this.events.filter(e => 
      e.category === 'message' && e.action === 'sent'
    );

    const responseEvents = this.events.filter(e => 
      e.category === 'response' && e.action === 'received'
    );

    // Group by hour of day
    const hourlyData = Array(24).fill(0).map(() => ({ sent: 0, responses: 0 }));
    
    messageEvents.forEach(e => {
      const hour = new Date(e.timestamp).getHours();
      hourlyData[hour].sent++;
    });

    responseEvents.forEach(e => {
      const hour = new Date(e.timestamp).getHours();
      hourlyData[hour].responses++;
    });

    return hourlyData.map((data, hour) => ({
      hour,
      sent: data.sent,
      responses: data.responses,
      responseRate: data.sent > 0 ? (data.responses / data.sent * 100).toFixed(1) : 0
    }));
  }

  /**
   * Get user engagement metrics
   */
  getUserEngagementMetrics() {
    const last30Days = Date.now() - (30 * 24 * 60 * 60 * 1000);
    const recentEvents = this.events.filter(e => e.timestamp >= last30Days);

    const profileViews = recentEvents.filter(e => 
      e.category === 'engagement' && e.action === 'profile_view'
    ).length;

    const conversationsStarted = recentEvents.filter(e => 
      e.category === 'engagement' && e.action === 'conversation_started'
    ).length;

    const messagesSent = recentEvents.filter(e => 
      e.category === 'message' && e.action === 'sent'
    ).length;

    return {
      profileViews,
      conversationsStarted,
      messagesSent,
      conversionRate: profileViews > 0 
        ? (conversationsStarted / profileViews * 100).toFixed(1) + '%'
        : '0%',
      messagesPerConversation: conversationsStarted > 0
        ? (messagesSent / conversationsStarted).toFixed(1)
        : '0'
    };
  }

  /**
   * Calculate ROI
   */
  calculateROI() {
    const hoursSaved = this.metrics.timeSaved.hoursSaved;
    const hourlyRate = 50; // Assumed hourly rate in dollars
    const estimatedValue = hoursSaved * hourlyRate;
    
    return {
      hoursSaved: hoursSaved.toFixed(1),
      hourlyRate,
      estimatedValue: estimatedValue.toFixed(2),
      currency: 'USD'
    };
  }

  /**
   * Update resource usage cost
   */
  async updateResourceCost(cost) {
    this.metrics.roi.totalCost += cost;
    
    if (this.metrics.messages.sent > 0) {
      this.metrics.roi.costPerMessage = this.metrics.roi.totalCost / this.metrics.messages.sent;
    }

    await this.saveMetrics();
  }

  /**
   * Generate custom report
   */
  generateReport(startDate, endDate, metrics = []) {
    const start = new Date(startDate).getTime();
    const end = new Date(endDate).getTime();

    const periodEvents = this.events.filter(e => 
      e.timestamp >= start && e.timestamp <= end
    );

    const report = {
      period: {
        start: startDate,
        end: endDate,
        days: Math.ceil((end - start) / (24 * 60 * 60 * 1000))
      },
      summary: {}
    };

    // Include requested metrics
    if (metrics.includes('messages') || metrics.length === 0) {
      const messagesSent = periodEvents.filter(e => 
        e.category === 'message' && e.action === 'sent'
      ).length;
      
      const messagesFailed = periodEvents.filter(e => 
        e.category === 'message' && e.action === 'failed'
      ).length;

      report.summary.messages = {
        sent: messagesSent,
        failed: messagesFailed,
        successRate: (messagesSent + messagesFailed) > 0
          ? (messagesSent / (messagesSent + messagesFailed) * 100).toFixed(1) + '%'
          : '0%'
      };
    }

    if (metrics.includes('responses') || metrics.length === 0) {
      const responsesReceived = periodEvents.filter(e => 
        e.category === 'response' && e.action === 'received'
      ).length;

      const messagesSent = periodEvents.filter(e => 
        e.category === 'message' && e.action === 'sent'
      ).length;

      report.summary.responses = {
        received: responsesReceived,
        responseRate: messagesSent > 0
          ? (responsesReceived / messagesSent * 100).toFixed(1) + '%'
          : '0%'
      };
    }

    if (metrics.includes('engagement') || metrics.length === 0) {
      report.summary.engagement = {
        profileViews: periodEvents.filter(e => 
          e.category === 'engagement' && e.action === 'profile_view'
        ).length,
        conversationsStarted: periodEvents.filter(e => 
          e.category === 'engagement' && e.action === 'conversation_started'
        ).length
      };
    }

    return report;
  }

  /**
   * Export analytics data
   */
  exportData(format = 'json') {
    const data = {
      metrics: this.metrics,
      events: this.events,
      exportedAt: Date.now()
    };

    if (format === 'csv') {
      return this.convertToCSV(data);
    }

    return JSON.stringify(data, null, 2);
  }

  /**
   * Convert data to CSV format
   */
  convertToCSV(data) {
    const headers = ['Timestamp', 'Category', 'Action', 'Label', 'Value'];
    const rows = data.events.map(e => [
      new Date(e.timestamp).toISOString(),
      e.category,
      e.action,
      e.label || '',
      e.value || ''
    ]);

    return [headers, ...rows]
      .map(row => row.join(','))
      .join('\n');
  }

  /**
   * Format response time
   */
  formatResponseTime(milliseconds) {
    const hours = milliseconds / (1000 * 60 * 60);
    if (hours < 1) {
      return `${Math.round(hours * 60)} minutes`;
    } else if (hours < 24) {
      return `${hours.toFixed(1)} hours`;
    } else {
      return `${(hours / 24).toFixed(1)} days`;
    }
  }

  /**
   * Format time saved
   */
  formatTimeSaved(hours) {
    if (hours < 1) {
      return `${Math.round(hours * 60)} minutes`;
    } else {
      return `${hours.toFixed(1)} hours`;
    }
  }

  /**
   * Save events to storage
   */
  async saveEvents() {
    await chrome.storage.local.set({ analyticsEvents: this.events });
  }

  /**
   * Save metrics to storage
   */
  async saveMetrics() {
    await chrome.storage.local.set({ analyticsMetrics: this.metrics });
  }

  /**
   * Generate unique ID
   */
  generateId() {
    return `evt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Clear all analytics data
   */
  async clearAll() {
    this.events = [];
    this.metrics = {
      messages: { sent: 0, failed: 0, pending: 0, scheduled: 0 },
      responses: { received: 0, responseRate: 0, avgResponseTime: 0 },
      engagement: { profileViews: 0, conversationsStarted: 0, conversationsActive: 0 },
      timeSaved: { totalMinutes: 0, manualTimeEstimate: 0, automationTimeActual: 0 },
      roi: { hoursSaved: 0, costPerMessage: 0, totalCost: 0 }
    };

    await this.saveEvents();
    await this.saveMetrics();
  }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = Analytics;
}
